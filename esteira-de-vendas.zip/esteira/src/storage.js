// ============================================================
// CAMADA DE DADOS — funciona em qualquer hospedagem
// ------------------------------------------------------------
// Sem configurar nada: salva no navegador (localStorage). Cada
// pessoa tem a própria cópia — bom para testar.
//
// Para COMPARTILHAR entre o time (todos veem o mesmo): crie uma
// conta grátis em jsonbin.io, gere uma "Master Key" e um "Bin",
// e preencha as duas constantes no arquivo .env (veja o LEIA-ME).
// ============================================================

const BIN_ID = import.meta.env.VITE_JSONBIN_BIN_ID || "";
const MASTER_KEY = import.meta.env.VITE_JSONBIN_KEY || "";
const LOCAL_KEY = "esteira-vendas-v2";
const usaNuvem = Boolean(BIN_ID && MASTER_KEY);

async function lerNuvem() {
  const r = await fetch(`https://api.jsonbin.io/v3/b/${BIN_ID}/latest`, {
    headers: { "X-Master-Key": MASTER_KEY },
  });
  if (!r.ok) throw new Error("falha ao ler");
  const j = await r.json();
  return j.record;
}

async function gravarNuvem(dados) {
  const r = await fetch(`https://api.jsonbin.io/v3/b/${BIN_ID}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", "X-Master-Key": MASTER_KEY },
    body: JSON.stringify(dados),
  });
  if (!r.ok) throw new Error("falha ao gravar");
}

export const storage = {
  modo: usaNuvem ? "nuvem" : "local",

  async carregar() {
    if (usaNuvem) {
      try {
        const d = await lerNuvem();
        return d && d.vendas ? d : { vendas: [], analistas: [] };
      } catch {
        // se a nuvem falhar, cai para o local para não travar o time
        const raw = localStorage.getItem(LOCAL_KEY);
        return raw ? JSON.parse(raw) : { vendas: [], analistas: [] };
      }
    }
    const raw = localStorage.getItem(LOCAL_KEY);
    return raw ? JSON.parse(raw) : { vendas: [], analistas: [] };
  },

  async salvar(dados) {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(dados)); // sempre guarda cópia local
    if (usaNuvem) await gravarNuvem(dados);
  },
};
