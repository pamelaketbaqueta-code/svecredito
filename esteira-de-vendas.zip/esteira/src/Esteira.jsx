import React, { useState, useEffect, useRef } from "react";
import * as XLSX from "xlsx";
import { storage } from "./storage";

// ============================================================
// ESTEIRA DE VENDAS — Secretaria de Vendas + Crédito (MCMV)
// Dados no armazenamento compartilhado (todos veem o mesmo).
// ============================================================
const STORE_KEY = "esteira-vendas-v2";

// ---------- ESTÁGIOS REAIS (da imagem) ----------
// bloco: PROPOSTA | ESTEIRA | VALIDADA | OUT  | esteira:true entra no Kanban
const ESTAGIOS = [
  { id: "CP_ANALISANDO", nome: "Analisando contrato", bloco: "PROPOSTA" },
  { id: "CP_AG_SICAQ_LEAD", nome: "Aguardando SICAQ lead", bloco: "PROPOSTA" },
  { id: "CP_CCA_APROVADO", nome: "CCA - Aprovado lead", bloco: "PROPOSTA" },
  { id: "CP_CCA_PENDENCIA", nome: "CCA - Pendência lead", bloco: "PROPOSTA" },
  { id: "CP_FALTA_DOC_CEF", nome: "Falta documentação - CEF", bloco: "PROPOSTA" },
  { id: "CP_LEAD_AG_SINAL", nome: "Lead aprovado - aguardando sinal", bloco: "PROPOSTA" },
  { id: "CP_SINAL_AG_SICAQ", nome: "Sinal pago - aguardando SICAQ", bloco: "PROPOSTA" },
  { id: "CP_FALTA_DOC_VD", nome: "Falta documentação - venda direta", bloco: "PROPOSTA" },
  { id: "CP_DESISTENCIA", nome: "Desistência (proposta)", bloco: "PROPOSTA" },
  { id: "CP_RESTRICAO", nome: "Restrição (proposta)", bloco: "PROPOSTA" },
  { id: "V_CONTRATO_100", nome: "Contrato 100% OK (comercial)", bloco: "ESTEIRA", esteira: true },
  { id: "V_TRIAGEM_DEV_PEND", nome: "Triagem devolvida c/ pendência", bloco: "ESTEIRA", esteira: true },
  { id: "V_DEV_PEND_COMERCIAL", nome: "Devolvido c/ pendência comercial", bloco: "ESTEIRA", esteira: true },
  { id: "V_TRIAGEM_CONTRATOS", nome: "Triagem de contratos", bloco: "ESTEIRA", esteira: true },
  { id: "V_CREDITO_SOLIC_DOCS", nome: "Crédito solicitando docs", bloco: "ESTEIRA", esteira: true },
  { id: "V_AG_COMPLETO_VALID", nome: "Aguardando completo e validado", bloco: "ESTEIRA", esteira: true },
  { id: "V_DEV_PEND_CCA", nome: "Devolvido c/ pendência CCA", bloco: "ESTEIRA", esteira: true },
  { id: "V_COMPLETO_VALIDADO", nome: "Completo e validado", bloco: "ESTEIRA", esteira: true },
  { id: "V_AG_ASSINATURA", nome: "Aguardando assinatura", bloco: "ESTEIRA", esteira: true },
  { id: "SV_VALIDADO_CEF", nome: "Validado CEF (SV)", bloco: "VALIDADA", esteira: true },
  { id: "SV_VALIDADO_DIRETO", nome: "Validado direto/NR (SV)", bloco: "VALIDADA", esteira: true },
  { id: "DESISTENCIA", nome: "Desistência", bloco: "OUT" },
  { id: "RESTRICAO", nome: "Restrição", bloco: "OUT" },
];
const BLOCOS = {
  PROPOSTA: { nome: "Comercial Proposta", cor: "#7C5CBF", bg: "#F1EBFA" },
  ESTEIRA: { nome: "Venda na esteira", cor: "#2456A6", bg: "#E9EFF8" },
  VALIDADA: { nome: "Validadas", cor: "#2E8B57", bg: "#E7F4EC" },
  OUT: { nome: "Encerradas", cor: "#B03A3A", bg: "#F9E9E9" },
};
const estDef = (id) => ESTAGIOS.find((e) => e.id === id) || ESTAGIOS[0];
const corEst = (id) => BLOCOS[estDef(id).bloco].cor;
const bgEst = (id) => BLOCOS[estDef(id).bloco].bg;

// ---------- CHECKLISTS por time ----------
const CHECK_SV = [
  ["sv_fluxo", "Fluxo ANAPRO × UAU (valores conferem)"],
  ["sv_alcada", "Alçada, em tempo e aprovação"],
  ["sv_renda_norm", "Renda × normativo"],
  ["sv_data_prazo", "Data de contrato dentro do prazo"],
  ["sv_datas_iguais", "Datas de contrato ANAPRO = UAU"],
  ["sv_parceria", "Parceria OK"],
  ["sv_ger_corretor", "Gerente como corretor"],
  ["sv_renda_cat", "Renda × categoria de uso"],
  ["sv_sicaq_compl", "SICAQ completo"],
  ["sv_ret", "RET (faixa correta)"],
  ["sv_sicaq_valid", "Validade do SICAQ"],
  ["sv_sicaq_data", "Data SICAQ OK"],
  ["sv_aprovacao", "Contrato: aprovação"],
  ["sv_clausula", "Contrato: cláusula em tempo"],
  ["sv_sinal", "Contrato: sinal"],
  ["sv_fianca", "Contrato: termo de fiança"],
  ["sv_doc_digital", "Doc. digital disponível p/ assinatura"],
];
const CHECK_CREDITO = [
  ["cr_avaliacao", "Valor de avaliação conferido"],
  ["cr_diferenca", "Diferença de valores OK"],
  ["cr_repasse", "Repasse (prazo/condição)"],
  ["cr_melhoria", "Melhoria avaliada"],
  ["cr_politica", "Política de crédito atendida"],
  ["cr_garantia", "Garantia definida"],
  ["cr_dependente", "Tipo de dependente conferido"],
  ["cr_banco", "Banco / linha confirmados"],
  ["cr_erros", "Sem erros no processo"],
  ["cr_doc_ok", "Documentação OK para seguir"],
];
const CHECK_STATUS = ["PENDENTE", "OK", "VERIFICAR", "NA"];
const CHECK_LABEL = { PENDENTE: "—", OK: "OK", VERIFICAR: "Verificar", NA: "N/A" };
const CHECK_COLOR = { PENDENTE: "#94A3B8", OK: "#2E8B57", VERIFICAR: "#C77E1B", NA: "#64748B" };
const TODOS_CHECKS = [...CHECK_SV, ...CHECK_CREDITO];
const novoChecklist = () => Object.fromEntries(TODOS_CHECKS.map(([k]) => [k, { status: "PENDENTE", obs: "" }]));

// ---------- util ----------
const fmtBRL = (v) => (v === "" || v == null || isNaN(Number(v)) ? "—" : Number(v).toLocaleString("pt-BR", { style: "currency", currency: "BRL" }));
const fmtData = (iso) => (iso ? new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "—");
const mascaraCPF = (cpf) => { const d = String(cpf || "").replace(/\D/g, ""); return d.length === 11 ? `***.${d.slice(3, 6)}.${d.slice(6, 9)}-**` : cpf || "—"; };
const diasParado = (iso) => (iso ? Math.floor((Date.now() - new Date(iso).getTime()) / 86400000) : 0);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const iniciais = (n) => String(n || "").split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

const S = {
  input: { width: "100%", padding: "8px 10px", border: "1px solid #D5DBE3", borderRadius: 6, fontSize: 13, background: "#fff", color: "#1B2733", outline: "none", boxSizing: "border-box" },
  label: { fontSize: 11, fontWeight: 600, color: "#5B6B7C", textTransform: "uppercase", letterSpacing: 0.4, display: "block", marginBottom: 4 },
  btn: (v = "primary") => ({ padding: "8px 14px", borderRadius: 6, fontSize: 13, fontWeight: 600, cursor: "pointer", border: v === "ghost" ? "1px solid #D5DBE3" : "none", background: v === "primary" ? "#2456A6" : v === "danger" ? "#B03A3A" : v === "ok" ? "#2E8B57" : "#fff", color: v === "ghost" ? "#1B2733" : "#fff" }),
};

export default function App() {
  const [db, setDb] = useState(null);
  const [tela, setTela] = useState("kanban");
  const [usuario, setUsuario] = useState("");
  const [papel, setPapel] = useState("SV");
  const [vendaAberta, setVendaAberta] = useState(null);
  const [busca, setBusca] = useState("");
  const [filtroAnalista, setFiltroAnalista] = useState("");
  const [filtroEstagio, setFiltroEstagio] = useState("");
  const [minhaFila, setMinhaFila] = useState(false);
  const [toast, setToast] = useState(null);
  const [erroCarga, setErroCarga] = useState(false);
  const dragId = useRef(null);

  useEffect(() => {
    (async () => {
      try { setDb(await storage.carregar()); }
      catch { setDb({ vendas: [], analistas: [] }); }
    })().catch(() => setErroCarga(true));
  }, []);

  const persistir = async (novo) => {
    setDb(novo);
    try { await storage.salvar(novo); }
    catch { avisar("Falha ao salvar — verifique a conexão", true); }
  };
  const avisar = (msg, erro = false) => { setToast({ msg, erro }); setTimeout(() => setToast(null), 3200); };
  const registrar = (v, texto) => ({ ...v, historico: [{ quando: new Date().toISOString(), quem: usuario || "—", papel, texto }, ...(v.historico || [])] });

  const salvarVenda = (vAtual, logTexto) => {
    let v = logTexto ? registrar(vAtual, logTexto) : vAtual;
    const novo = { ...db, vendas: db.vendas.map((x) => (x.id === v.id ? v : x)) };
    persistir(novo);
    if (vendaAberta && vendaAberta.id === v.id) setVendaAberta(v);
  };

  const criarVenda = (d) => ({
    id: uid(), codigo: d.codigo || "", processo: d.processo || "", link: d.link || "", cliente: d.cliente || "", cpf: d.cpf || "",
    empreendimento: d.empreendimento || "", unidade: d.unidade || "", tipologia: d.tipologia || "", cat_uso: d.cat_uso || "",
    m2: d.m2 || "", vlr_venda: d.vlr_venda || "", vlr_avaliacao: d.vlr_avaliacao || "", renda: d.renda || "",
    corretor: d.corretor || "", gerente: d.gerente || "", gestor: d.gestor || "", diretor: d.diretor || "",
    banco: d.banco || "", diferenca: d.diferenca || "", repasse: d.repasse || "", melhoria: d.melhoria || "",
    politica: d.politica || "", garantia: d.garantia || "", dependente: d.dependente || "", erros: d.erros || "", resultado: d.resultado || "",
    data_contrato: d.data_contrato || "", semana: d.semana || "",
    analista_sv: d.analista_sv || "", analista_credito: d.analista_credito || "", assistente_credito: d.assistente_credito || "",
    estagio: d.estagio || "CP_ANALISANDO", data_estagio: new Date().toISOString(), obs: d.obs || "",
    checklist: novoChecklist(), pendencias: [],
    historico: [{ quando: new Date().toISOString(), quem: usuario || "—", papel, texto: "Venda criada" }], criado_em: new Date().toISOString(),
  });

  const moverEstagio = (vendaId, destino) => {
    const v = db.vendas.find((x) => x.id === vendaId);
    if (!v || v.estagio === destino) return;
    if (destino === "SV_VALIDADO_CEF" || destino === "SV_VALIDADO_DIRETO") {
      const lista = papel === "CREDITO" ? CHECK_CREDITO : CHECK_SV;
      const pend = lista.filter(([k]) => !["OK", "NA"].includes(v.checklist?.[k]?.status));
      if (pend.length) return avisar(`Não dá para validar: ${pend.length} item(ns) do checklist ${papel} sem OK/N/A`, true);
    }
    salvarVenda({ ...v, estagio: destino, data_estagio: new Date().toISOString() }, `Moveu para "${estDef(destino).nome}"`);
    avisar(`Movida para ${estDef(destino).nome}`);
  };

  const adicionarAnalista = (nome) => { const n = nome.trim(); if (!n || db.analistas.includes(n)) return; persistir({ ...db, analistas: [...db.analistas, n].sort() }); };

  if (erroCarga) return <div style={{ padding: 40, fontFamily: "system-ui" }}>Não foi possível carregar. Recarregue a página.</div>;
  if (!db) return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#F5F6F8", color: "#5B6B7C", fontFamily: "system-ui" }}>Carregando a esteira…</div>;

  const analistaCampo = papel === "CREDITO" ? "analista_credito" : "analista_sv";
  const vendasFiltradas = db.vendas.filter((v) => {
    if (filtroEstagio && v.estagio !== filtroEstagio) return false;
    if (minhaFila && usuario && v[analistaCampo] !== usuario) return false;
    if (filtroAnalista && v[analistaCampo] !== filtroAnalista) return false;
    if (busca) { const t = busca.toLowerCase(); if (![v.cliente, v.cpf, v.codigo, v.processo, v.empreendimento].some((c) => String(c || "").toLowerCase().includes(t))) return false; }
    return true;
  });

  const fonte = `'Archivo','Segoe UI',system-ui,sans-serif`;

  return (
    <div style={{ minHeight: "100vh", background: "#F5F6F8", fontFamily: fonte, color: "#1B2733" }}>
      <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&display=swap" rel="stylesheet" />

      <header style={{ background: "#1B2733", color: "#fff", padding: "0 16px", display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", minHeight: 54 }}>
        <div style={{ fontWeight: 800, fontSize: 16, padding: "12px 8px 12px 0", whiteSpace: "nowrap" }}>ESTEIRA<span style={{ color: "#8FB4E8" }}>•</span>VENDAS</div>
        {[["kanban", "Kanban"], ["lista", "Lista"], ["painel", "Painel"], ["nova", "Nova"], ["importar", "Importar"]].map(([id, nome]) => (
          <button key={id} onClick={() => setTela(id)} style={{ background: tela === id ? "#2456A6" : "transparent", color: "#fff", border: "none", padding: "8px 12px", borderRadius: 6, fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: fonte }}>{nome}</button>
        ))}
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8, padding: "8px 0", flexWrap: "wrap" }}>
          <div style={{ display: "flex", background: "#0E1620", borderRadius: 7, padding: 2 }}>
            {[["SV", "Sec. Vendas"], ["CREDITO", "Crédito"]].map(([p, l]) => (
              <button key={p} onClick={() => setPapel(p)} style={{ background: papel === p ? "#2456A6" : "transparent", color: "#fff", border: "none", padding: "6px 10px", borderRadius: 5, fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: fonte }}>{l}</button>
            ))}
          </div>
          <select value={usuario} onChange={(e) => { if (e.target.value === "__novo") { const n = prompt("Nome do analista:"); if (n && n.trim()) { adicionarAnalista(n); setUsuario(n.trim()); } } else setUsuario(e.target.value); }} style={{ ...S.input, width: 150, padding: "6px 8px", fontSize: 12 }}>
            <option value="">— quem usa —</option>
            {db.analistas.map((a) => <option key={a} value={a}>{a}</option>)}
            <option value="__novo">+ cadastrar…</option>
          </select>
        </div>
      </header>

      {(tela === "kanban" || tela === "lista") && (
        <div style={{ padding: "12px 16px 0", display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <input placeholder="Buscar cliente, CPF, processo…" value={busca} onChange={(e) => setBusca(e.target.value)} style={{ ...S.input, width: 230 }} />
          <select value={filtroAnalista} onChange={(e) => setFiltroAnalista(e.target.value)} style={{ ...S.input, width: 170 }}>
            <option value="">Analista ({papel === "CREDITO" ? "crédito" : "SV"})</option>
            {db.analistas.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
          {tela === "lista" && (
            <select value={filtroEstagio} onChange={(e) => setFiltroEstagio(e.target.value)} style={{ ...S.input, width: 220 }}>
              <option value="">Todos os estágios</option>
              {Object.keys(BLOCOS).map((b) => (
                <optgroup key={b} label={BLOCOS[b].nome}>
                  {ESTAGIOS.filter((e) => e.bloco === b).map((e) => <option key={e.id} value={e.id}>{e.nome}</option>)}
                </optgroup>
              ))}
            </select>
          )}
          <label style={{ fontSize: 13, display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
            <input type="checkbox" checked={minhaFila} onChange={(e) => setMinhaFila(e.target.checked)} disabled={!usuario} /> Minha fila
          </label>
          <span style={{ marginLeft: "auto", fontSize: 12, color: "#5B6B7C" }}>{vendasFiltradas.length} venda(s){tela === "kanban" ? " · arraste para mover" : ""}</span>
        </div>
      )}

      {tela === "kanban" && <Kanban vendas={vendasFiltradas} total={db.vendas.length} papel={papel} dragId={dragId} mover={moverEstagio} abrir={setVendaAberta} irImportar={() => setTela("importar")} />}
      {tela === "lista" && <Lista vendas={vendasFiltradas} papel={papel} abrir={setVendaAberta} />}
      {tela === "painel" && <Painel vendas={db.vendas} papel={papel} abrir={setVendaAberta} />}
      {tela === "nova" && <NovaVenda analistas={db.analistas} onCriar={(d) => { if (!d.cliente.trim()) return avisar("Informe o cliente", true); persistir({ ...db, vendas: [criarVenda(d), ...db.vendas] }); avisar("Venda cadastrada"); setTela("kanban"); }} />}
      {tela === "importar" && <Importar onImportar={(linhas) => { const novas = linhas.map(criarVenda); persistir({ ...db, vendas: [...novas, ...db.vendas] }); avisar(`${novas.length} venda(s) importada(s)`); setTela("lista"); }} />}

      {vendaAberta && (
        <Detalhe venda={db.vendas.find((v) => v.id === vendaAberta.id) || vendaAberta} analistas={db.analistas} usuario={usuario} papel={papel} fechar={() => setVendaAberta(null)} salvar={salvarVenda} mover={moverEstagio} avisar={avisar} />
      )}

      {toast && <div style={{ position: "fixed", bottom: 20, left: "50%", transform: "translateX(-50%)", background: toast.erro ? "#B03A3A" : "#1B2733", color: "#fff", padding: "10px 18px", borderRadius: 8, fontSize: 13, fontWeight: 600, zIndex: 99, boxShadow: "0 4px 14px rgba(0,0,0,.25)", maxWidth: "90vw" }}>{toast.msg}</div>}
    </div>
  );
}

// ============================================================
// KANBAN — só estágios da esteira + validadas
// ============================================================
function Kanban({ vendas, total, papel, dragId, mover, abrir, irImportar }) {
  const cols = ESTAGIOS.filter((e) => e.esteira);
  const analistaCampo = papel === "CREDITO" ? "analista_credito" : "analista_sv";
  if (total === 0)
    return (
      <div style={{ padding: 16 }}>
        <div style={{ background: "#fff", border: "1px dashed #C7CFDA", borderRadius: 10, padding: 40, textAlign: "center", color: "#5B6B7C" }}>
          <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 6, color: "#1B2733" }}>A esteira está vazia</div>
          Importe as planilhas na aba <b>Importar</b> ou cadastre em <b>Nova</b>.
          <div style={{ marginTop: 14 }}><button onClick={irImportar} style={S.btn()}>Ir para Importar</button></div>
        </div>
      </div>
    );
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontSize: 12, color: "#5B6B7C", marginBottom: 8 }}>Mostrando os estágios da <b>esteira</b> e <b>validadas</b>. Os estágios de Comercial Proposta ficam na aba <b>Lista</b>.</div>
      <div style={{ display: "flex", gap: 12, overflowX: "auto", paddingBottom: 12, alignItems: "flex-start" }}>
        {cols.map((est) => {
          const cards = vendas.filter((v) => v.estagio === est.id);
          const cor = BLOCOS[est.bloco].cor, bg = BLOCOS[est.bloco].bg;
          return (
            <div key={est.id} onDragOver={(e) => e.preventDefault()} onDrop={() => { if (dragId.current) mover(dragId.current, est.id); dragId.current = null; }} style={{ minWidth: 230, width: 230, background: bg, borderRadius: 10, border: `1px solid ${cor}22`, flexShrink: 0 }}>
              <div style={{ padding: "9px 11px", display: "flex", alignItems: "center", gap: 7, borderBottom: `2px solid ${cor}` }}>
                <span style={{ fontWeight: 700, fontSize: 12, lineHeight: 1.2 }}>{est.nome}</span>
                <span style={{ marginLeft: "auto", fontSize: 12, fontWeight: 700, color: cor }}>{cards.length}</span>
              </div>
              <div style={{ padding: 8, display: "flex", flexDirection: "column", gap: 8, minHeight: 50 }}>
                {cards.map((v) => {
                  const dias = diasParado(v.data_estagio);
                  const validada = est.bloco === "VALIDADA";
                  const an = v[analistaCampo];
                  return (
                    <div key={v.id} draggable onDragStart={() => (dragId.current = v.id)} onClick={() => abrir(v)} style={{ background: "#fff", borderRadius: 8, padding: 10, cursor: "grab", boxShadow: "0 1px 2px rgba(20,30,45,.08)", border: "1px solid #E2E7EE" }}>
                      <div style={{ fontWeight: 700, fontSize: 12.5, marginBottom: 2 }}>{v.cliente || "(sem nome)"}</div>
                      <div style={{ fontSize: 11, color: "#5B6B7C" }}>{v.empreendimento || "—"}{v.unidade ? ` · ${v.unidade}` : ""}</div>
                      <div style={{ fontSize: 12, fontWeight: 600, margin: "4px 0" }}>{fmtBRL(v.vlr_venda)}</div>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        {an && <span title={an} style={{ width: 20, height: 20, borderRadius: "50%", background: papel === "CREDITO" ? "#7C5CBF" : "#2456A6", color: "#fff", fontSize: 9, fontWeight: 700, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>{iniciais(an)}</span>}
                        {validada ? <span style={{ marginLeft: "auto", fontSize: 9, fontWeight: 800, color: "#2E8B57", border: "1.5px solid #2E8B57", borderRadius: 4, padding: "1px 5px", letterSpacing: 1, transform: "rotate(-3deg)" }}>VALIDADO</span>
                          : <span style={{ marginLeft: "auto", fontSize: 10.5, fontWeight: 700, color: dias > 5 ? "#fff" : "#5B6B7C", background: dias > 5 ? "#B03A3A" : "#EEF1F5", borderRadius: 10, padding: "2px 7px" }}>{dias}d</span>}
                      </div>
                    </div>
                  );
                })}
                {cards.length === 0 && <div style={{ fontSize: 11, color: "#8B99A9", textAlign: "center", padding: 6 }}>vazio</div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// LISTA — todos os estágios, agrupados por bloco
// ============================================================
function Lista({ vendas, papel, abrir }) {
  const analistaCampo = papel === "CREDITO" ? "analista_credito" : "analista_sv";
  const grupos = Object.keys(BLOCOS).map((b) => ({ bloco: b, def: BLOCOS[b], itens: vendas.filter((v) => estDef(v.estagio).bloco === b) })).filter((g) => g.itens.length);
  return (
    <div style={{ padding: 16 }}>
      {vendas.length === 0 && <div style={{ background: "#fff", border: "1px dashed #C7CFDA", borderRadius: 10, padding: 30, textAlign: "center", color: "#5B6B7C" }}>Nenhuma venda com esses filtros.</div>}
      {grupos.map((g) => (
        <div key={g.bloco} style={{ marginBottom: 18 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: g.def.cor }} />
            <span style={{ fontWeight: 800, fontSize: 13, textTransform: "uppercase", letterSpacing: 0.5 }}>{g.def.nome}</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: g.def.cor }}>{g.itens.length}</span>
          </div>
          <div style={{ background: "#fff", border: "1px solid #E2E7EE", borderRadius: 10, overflow: "hidden" }}>
            <div style={{ overflowX: "auto" }}>
              <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 12.5, minWidth: 720 }}>
                <thead>
                  <tr style={{ background: "#F0F2F6", textAlign: "left" }}>
                    {["Cliente", "Empreend. / Unid.", "Estágio", "Valor", papel === "CREDITO" ? "Analista crédito" : "Analista SV", "Dias", ""].map((h) => <th key={h} style={{ padding: "8px 10px", whiteSpace: "nowrap", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.4, color: "#5B6B7C" }}>{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {g.itens.map((v) => (
                    <tr key={v.id} onClick={() => abrir(v)} style={{ cursor: "pointer", borderTop: "1px solid #EEF1F5" }}>
                      <td style={{ padding: "8px 10px", fontWeight: 600 }}>{v.cliente || "(sem nome)"}<div style={{ fontSize: 10.5, color: "#8B99A9", fontWeight: 400 }}>CPF {mascaraCPF(v.cpf)}{v.processo ? ` · proc ${v.processo}` : ""}</div></td>
                      <td style={{ padding: "8px 10px", color: "#5B6B7C", whiteSpace: "nowrap" }}>{v.empreendimento || "—"}{v.unidade ? ` · ${v.unidade}` : ""}</td>
                      <td style={{ padding: "8px 10px", whiteSpace: "nowrap" }}><span style={{ fontSize: 11, fontWeight: 700, color: corEst(v.estagio), background: bgEst(v.estagio), borderRadius: 5, padding: "2px 7px" }}>{estDef(v.estagio).nome}</span></td>
                      <td style={{ padding: "8px 10px", whiteSpace: "nowrap" }}>{fmtBRL(v.vlr_venda)}</td>
                      <td style={{ padding: "8px 10px", whiteSpace: "nowrap" }}>{v[analistaCampo] || "—"}</td>
                      <td style={{ padding: "8px 10px", fontWeight: 700, color: diasParado(v.data_estagio) > 5 ? "#B03A3A" : "#5B6B7C" }}>{diasParado(v.data_estagio)}d</td>
                      <td style={{ padding: "8px 10px", color: "#2456A6", fontWeight: 600 }}>abrir →</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ============================================================
// DETALHE — abas Dados, SV, Crédito, Pendências, IA, Histórico
// ============================================================
function Detalhe({ venda, analistas, usuario, papel, fechar, salvar, mover, avisar }) {
  const [aba, setAba] = useState(papel === "CREDITO" ? "credito" : "sv");
  const [form, setForm] = useState(venda);
  const [novaPend, setNovaPend] = useState("");
  const [ia, setIa] = useState(null);
  const [iaCarregando, setIaCarregando] = useState(false);
  useEffect(() => { setForm(venda); setAba(papel === "CREDITO" ? "credito" : "sv"); }, [venda.id]);

  const setCheck = (chave, campo, valor, rotulo) => {
    const item = venda.checklist?.[chave] || { status: "PENDENTE", obs: "" };
    const novo = { ...venda, checklist: { ...venda.checklist, [chave]: { ...item, [campo]: valor, quem: usuario || "—", quando: new Date().toISOString() } } };
    salvar(novo, campo === "status" ? `Checklist "${rotulo}": ${CHECK_LABEL[valor]}` : null);
  };
  const progresso = (lista) => { const ok = lista.filter(([k]) => ["OK", "NA"].includes(venda.checklist?.[k]?.status)).length; return { ok, total: lista.length }; };

  const devolverPend = (lista, nomeTime, estagioDestino) => {
    const verificar = lista.filter(([k]) => venda.checklist?.[k]?.status === "VERIFICAR");
    if (!verificar.length) return avisar("Nenhum item marcado como Verificar", true);
    const novas = verificar.map(([k, rot]) => ({ id: uid(), descricao: `[${nomeTime}] ${rot}${venda.checklist[k].obs ? " — " + venda.checklist[k].obs : ""}`, resolvida: false, criado_em: new Date().toISOString(), criado_por: usuario || "—" }));
    salvar({ ...venda, pendencias: [...novas, ...(venda.pendencias || [])], estagio: estagioDestino, data_estagio: new Date().toISOString() }, `Devolvida (${nomeTime}) com ${novas.length} pendência(s)`);
    avisar("Devolvida com pendências");
  };

  const analisarIA = async () => {
    setIaCarregando(true); setIa(null);
    try {
      const payload = {
        venda: { ...venda, checklist: undefined, historico: undefined },
        checklist: TODOS_CHECKS.map(([k, rot]) => ({ item: rot, status: venda.checklist?.[k]?.status || "PENDENTE", obs: venda.checklist?.[k]?.obs || "" })),
        pendencias_abertas: (venda.pendencias || []).filter((p) => !p.resolvida).map((p) => p.descricao),
      };
      const resp = await fetch("/api/analisar", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ payload }),
      });
      const data = await resp.json();
      if (data.erro) throw new Error(data.erro);
      const texto = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
      setIa(JSON.parse(texto.replace(/```json|```/g, "").trim()));
    } catch { avisar("A análise de IA falhou. Tente novamente.", true); }
    setIaCarregando(false);
  };
  const corRisco = { baixo: "#2E8B57", medio: "#C77E1B", alto: "#B03A3A" };

  const campoTxt = (k, rotulo) => (
    <div><label style={S.label}>{rotulo}</label><input value={form[k] || ""} onChange={(e) => setForm({ ...form, [k]: e.target.value })} style={S.input} /></div>
  );

  const ChecklistBloco = ({ lista, nomeTime }) => {
    const pr = progresso(lista);
    return (
      <div>
        <div style={{ height: 8, background: "#EEF1F5", borderRadius: 4, marginBottom: 8, overflow: "hidden" }}>
          <div style={{ width: `${(pr.ok / pr.total) * 100}%`, height: "100%", background: "#2E8B57", transition: "width .3s" }} />
        </div>
        <div style={{ fontSize: 12, color: "#5B6B7C", marginBottom: 12 }}>{pr.ok} de {pr.total} itens OK/N/A</div>
        {lista.map(([k, rot]) => {
          const item = venda.checklist?.[k] || { status: "PENDENTE", obs: "" };
          return (
            <div key={k} style={{ border: "1px solid #E2E7EE", borderLeft: `4px solid ${CHECK_COLOR[item.status]}`, borderRadius: 7, padding: "9px 11px", marginBottom: 7 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                <span style={{ fontSize: 13, fontWeight: 600, flex: 1, minWidth: 150 }}>{rot}</span>
                <div style={{ display: "flex", gap: 3 }}>
                  {CHECK_STATUS.map((st) => (
                    <button key={st} onClick={() => setCheck(k, "status", st, rot)} style={{ padding: "3px 8px", fontSize: 11, fontWeight: 700, borderRadius: 5, cursor: "pointer", border: `1px solid ${item.status === st ? CHECK_COLOR[st] : "#D5DBE3"}`, background: item.status === st ? CHECK_COLOR[st] : "#fff", color: item.status === st ? "#fff" : "#5B6B7C" }}>{CHECK_LABEL[st]}</button>
                  ))}
                </div>
              </div>
              <input placeholder="Observação…" value={item.obs || ""} onChange={(e) => setCheck(k, "obs", e.target.value, rot)} style={{ ...S.input, marginTop: 7, fontSize: 12, padding: "6px 8px" }} />
              {item.quem && <div style={{ fontSize: 10.5, color: "#8B99A9", marginTop: 4 }}>por {item.quem} · {fmtData(item.quando)}</div>}
            </div>
          );
        })}
        <div style={{ display: "flex", gap: 8, marginTop: 4, flexWrap: "wrap" }}>
          <button onClick={() => mover(venda.id, "SV_VALIDADO_CEF")} style={S.btn("ok")}>Validar CEF</button>
          <button onClick={() => mover(venda.id, "SV_VALIDADO_DIRETO")} style={{ ...S.btn("ghost"), color: "#2E8B57", borderColor: "#2E8B57" }}>Validar direto/NR</button>
          <button onClick={() => devolverPend(lista, nomeTime, "V_DEV_PEND_COMERCIAL")} style={{ ...S.btn("ghost"), color: "#C77E1B", borderColor: "#C77E1B" }}>Devolver com pendências</button>
        </div>
      </div>
    );
  };

  const abas = [
    ["dados", "Dados"],
    ["sv", `SV ${progresso(CHECK_SV).ok}/${CHECK_SV.length}`],
    ["credito", `Crédito ${progresso(CHECK_CREDITO).ok}/${CHECK_CREDITO.length}`],
    ["pend", `Pendências (${(venda.pendencias || []).filter((p) => !p.resolvida).length})`],
    ["ia", "Análise IA"],
    ["hist", "Histórico"],
  ];

  return (
    <div onClick={fechar} style={{ position: "fixed", inset: 0, background: "rgba(15,23,33,.45)", zIndex: 50, display: "flex", justifyContent: "flex-end" }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "min(580px,100vw)", background: "#fff", height: "100%", overflowY: "auto", boxShadow: "-6px 0 24px rgba(0,0,0,.2)" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid #E2E7EE", position: "sticky", top: 0, background: "#fff", zIndex: 2 }}>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 800, fontSize: 17 }}>{venda.cliente || "(sem nome)"}</div>
              <div style={{ fontSize: 12, color: "#5B6B7C", marginTop: 2 }}>{venda.empreendimento || "—"}{venda.unidade ? ` · ${venda.unidade}` : ""} · CPF {mascaraCPF(venda.cpf)}{venda.processo ? ` · proc ${venda.processo}` : ""}</div>
              {venda.link && <a href={venda.link} target="_blank" rel="noreferrer" style={{ fontSize: 12, color: "#2456A6", fontWeight: 600 }}>abrir no ANAPRO ↗</a>}
            </div>
            <button onClick={fechar} style={{ ...S.btn("ghost"), padding: "6px 10px" }}>✕</button>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center", flexWrap: "wrap" }}>
            <select value={venda.estagio} onChange={(e) => mover(venda.id, e.target.value)} style={{ ...S.input, width: 230, borderLeft: `4px solid ${corEst(venda.estagio)}` }}>
              {Object.keys(BLOCOS).map((b) => <optgroup key={b} label={BLOCOS[b].nome}>{ESTAGIOS.filter((e) => e.bloco === b).map((e) => <option key={e.id} value={e.id}>{e.nome}</option>)}</optgroup>)}
            </select>
            <span style={{ fontSize: 11.5, color: "#5B6B7C" }}>{diasParado(venda.data_estagio)}d nesta fase</span>
          </div>
          <div style={{ display: "flex", gap: 4, marginTop: 12, flexWrap: "wrap" }}>
            {abas.map(([id, nome]) => <button key={id} onClick={() => setAba(id)} style={{ padding: "7px 10px", borderRadius: 6, border: "none", cursor: "pointer", fontSize: 12, fontWeight: 600, background: aba === id ? "#1B2733" : "#EEF1F5", color: aba === id ? "#fff" : "#1B2733" }}>{nome}</button>)}
          </div>
        </div>

        <div style={{ padding: 20 }}>
          {aba === "dados" && (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div style={{ gridColumn: "1 / -1", fontWeight: 700, fontSize: 12, textTransform: "uppercase", color: "#5B6B7C" }}>Identificação</div>
              {campoTxt("cliente", "Cliente")}{campoTxt("cpf", "CPF")}{campoTxt("codigo", "Chave (CHV)")}{campoTxt("processo", "Nº processo")}
              {campoTxt("empreendimento", "Empreendimento")}{campoTxt("unidade", "Unidade")}{campoTxt("tipologia", "Tipologia")}{campoTxt("cat_uso", "Cat. de uso (HIS)")}
              <div style={{ gridColumn: "1 / -1", fontWeight: 700, fontSize: 12, textTransform: "uppercase", color: "#5B6B7C", marginTop: 6 }}>Valores</div>
              {campoTxt("vlr_venda", "Valor da venda")}{campoTxt("vlr_avaliacao", "Valor de avaliação")}{campoTxt("renda", "Renda")}{campoTxt("m2", "M²")}
              <div style={{ gridColumn: "1 / -1", fontWeight: 700, fontSize: 12, textTransform: "uppercase", color: "#5B6B7C", marginTop: 6 }}>Equipe comercial</div>
              {campoTxt("corretor", "Corretor(a)")}{campoTxt("gerente", "Gerente")}{campoTxt("gestor", "Gestor")}{campoTxt("diretor", "Diretor")}
              <div style={{ gridColumn: "1 / -1", fontWeight: 700, fontSize: 12, textTransform: "uppercase", color: "#5B6B7C", marginTop: 6 }}>Crédito</div>
              {campoTxt("banco", "Banco")}{campoTxt("repasse", "Repasse")}{campoTxt("diferenca", "Diferença de valores")}{campoTxt("melhoria", "Melhoria")}
              {campoTxt("politica", "Política de crédito")}{campoTxt("garantia", "Garantia")}{campoTxt("dependente", "Tipo de dependente")}{campoTxt("resultado", "Resultado final")}
              <div style={{ gridColumn: "1 / -1", fontWeight: 700, fontSize: 12, textTransform: "uppercase", color: "#5B6B7C", marginTop: 6 }}>Responsáveis</div>
              <div><label style={S.label}>Analista SV</label><select value={form.analista_sv || ""} onChange={(e) => setForm({ ...form, analista_sv: e.target.value })} style={S.input}><option value="">—</option>{analistas.map((a) => <option key={a} value={a}>{a}</option>)}</select></div>
              <div><label style={S.label}>Analista de crédito</label><select value={form.analista_credito || ""} onChange={(e) => setForm({ ...form, analista_credito: e.target.value })} style={S.input}><option value="">—</option>{analistas.map((a) => <option key={a} value={a}>{a}</option>)}</select></div>
              {campoTxt("assistente_credito", "Assistente de crédito")}{campoTxt("data_contrato", "Data contrato ANAPRO")}
              <div style={{ gridColumn: "1 / -1" }}><label style={S.label}>Observações</label><textarea value={form.obs || ""} onChange={(e) => setForm({ ...form, obs: e.target.value })} rows={2} style={{ ...S.input, resize: "vertical" }} /></div>
              <div style={{ gridColumn: "1 / -1" }}><button onClick={() => { salvar({ ...venda, ...form }, "Dados editados"); avisar("Dados salvos"); }} style={S.btn()}>Salvar dados</button></div>
            </div>
          )}
          {aba === "sv" && <ChecklistBloco lista={CHECK_SV} nomeTime="SV" />}
          {aba === "credito" && <ChecklistBloco lista={CHECK_CREDITO} nomeTime="Crédito" />}

          {aba === "pend" && (
            <div>
              <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
                <input placeholder="Nova pendência…" value={novaPend} onChange={(e) => setNovaPend(e.target.value)} style={S.input} />
                <button onClick={() => { if (!novaPend.trim()) return; const p = { id: uid(), descricao: novaPend.trim(), resolvida: false, criado_em: new Date().toISOString(), criado_por: usuario || "—" }; salvar({ ...venda, pendencias: [p, ...(venda.pendencias || [])] }, `Pendência: ${p.descricao}`); setNovaPend(""); }} style={S.btn()}>Adicionar</button>
              </div>
              {(venda.pendencias || []).length === 0 && <div style={{ color: "#8B99A9", fontSize: 13 }}>Nenhuma pendência.</div>}
              {(venda.pendencias || []).map((p) => (
                <label key={p.id} style={{ display: "flex", gap: 10, alignItems: "flex-start", padding: "9px 11px", border: "1px solid #E2E7EE", borderRadius: 7, marginBottom: 7, cursor: "pointer", background: p.resolvida ? "#F6F8F7" : "#fff" }}>
                  <input type="checkbox" checked={p.resolvida} onChange={(e) => { const novas = venda.pendencias.map((x) => x.id === p.id ? { ...x, resolvida: e.target.checked, resolvida_em: e.target.checked ? new Date().toISOString() : null } : x); salvar({ ...venda, pendencias: novas }, `${e.target.checked ? "Resolveu" : "Reabriu"}: ${p.descricao}`); }} style={{ marginTop: 3 }} />
                  <div><div style={{ fontSize: 13, textDecoration: p.resolvida ? "line-through" : "none", color: p.resolvida ? "#8B99A9" : "#1B2733" }}>{p.descricao}</div><div style={{ fontSize: 10.5, color: "#8B99A9" }}>por {p.criado_por} · {fmtData(p.criado_em)}</div></div>
                </label>
              ))}
            </div>
          )}

          {aba === "ia" && (
            <div>
              <p style={{ fontSize: 13, color: "#5B6B7C", marginTop: 0 }}>A IA revisa dados, checklists (SV e crédito) e pendências, e aponta risco e prováveis problemas.</p>
              <button onClick={analisarIA} disabled={iaCarregando} style={{ ...S.btn(), opacity: iaCarregando ? 0.6 : 1 }}>{iaCarregando ? "Analisando…" : "Analisar com IA"}</button>
              {ia && (
                <div style={{ marginTop: 16, border: "1px solid #E2E7EE", borderRadius: 10, padding: 16 }}>
                  <div style={{ display: "inline-block", padding: "4px 12px", borderRadius: 14, fontWeight: 800, fontSize: 12, textTransform: "uppercase", letterSpacing: 0.8, color: "#fff", background: corRisco[ia.risco] || "#5B6B7C", marginBottom: 10 }}>Risco {ia.risco}</div>
                  <p style={{ fontSize: 13.5, lineHeight: 1.55, marginTop: 0 }}>{ia.resumo}</p>
                  {(ia.pendencias_provaveis || []).length > 0 && (
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 12, textTransform: "uppercase", color: "#5B6B7C", margin: "10px 0 6px" }}>Pendências prováveis</div>
                      {ia.pendencias_provaveis.map((p, i) => (
                        <div key={i} style={{ display: "flex", gap: 8, alignItems: "center", padding: "7px 0", borderTop: "1px solid #EEF1F5", fontSize: 13 }}>
                          <span style={{ flex: 1 }}>{p}</span>
                          <button onClick={() => { const nova = { id: uid(), descricao: p, resolvida: false, criado_em: new Date().toISOString(), criado_por: "IA + " + (usuario || "—") }; salvar({ ...venda, pendencias: [nova, ...(venda.pendencias || [])] }, `Pendência (IA): ${p}`); avisar("Adicionada às pendências"); }} style={{ ...S.btn("ghost"), padding: "4px 9px", fontSize: 11.5 }}>+ Pendência</button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {aba === "hist" && (
            <div>
              {(venda.historico || []).length === 0 && <div style={{ color: "#8B99A9", fontSize: 13 }}>Sem eventos.</div>}
              {(venda.historico || []).map((h, i) => (
                <div key={i} style={{ display: "flex", gap: 10, padding: "9px 0", borderBottom: "1px solid #EEF1F5" }}>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: h.papel === "CREDITO" ? "#7C5CBF" : "#2456A6", marginTop: 5, flexShrink: 0 }} />
                  <div><div style={{ fontSize: 13 }}>{h.texto}</div><div style={{ fontSize: 11, color: "#8B99A9" }}>{h.quem}{h.papel ? ` (${h.papel === "CREDITO" ? "Crédito" : "SV"})` : ""} · {fmtData(h.quando)}</div></div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// PAINEL
// ============================================================
function Painel({ vendas, papel, abrir }) {
  const analistaCampo = papel === "CREDITO" ? "analista_credito" : "analista_sv";
  const naEsteira = vendas.filter((v) => estDef(v.estagio).bloco === "ESTEIRA");
  const propostas = vendas.filter((v) => estDef(v.estagio).bloco === "PROPOSTA");
  const validadas = vendas.filter((v) => estDef(v.estagio).bloco === "VALIDADA");
  const paradas = [...naEsteira].sort((a, b) => new Date(a.data_estagio) - new Date(b.data_estagio)).slice(0, 10);
  const porAnalista = {};
  naEsteira.forEach((v) => { const a = v[analistaCampo] || "Sem analista"; porAnalista[a] = (porAnalista[a] || 0) + 1; });
  const maxA = Math.max(1, ...Object.values(porAnalista));
  const card = (t, val, cor = "#1B2733") => <div style={{ background: "#fff", border: "1px solid #E2E7EE", borderRadius: 10, padding: "14px 18px", minWidth: 130, flex: 1 }}><div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, color: "#5B6B7C" }}>{t}</div><div style={{ fontSize: 28, fontWeight: 800, color: cor, marginTop: 4 }}>{val}</div></div>;

  return (
    <div style={{ padding: 16, maxWidth: 1000 }}>
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 18 }}>
        {card("Total de vendas", vendas.length)}
        {card("Em proposta", propostas.length, "#7C5CBF")}
        {card("Na esteira", naEsteira.length, "#2456A6")}
        {card("Validadas", validadas.length, "#2E8B57")}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 14 }}>
        <div style={{ background: "#fff", border: "1px solid #E2E7EE", borderRadius: 10, padding: 16 }}>
          <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 12 }}>Vendas por estágio</div>
          {ESTAGIOS.filter((e) => e.bloco !== "OUT").map((e) => {
            const n = vendas.filter((v) => v.estagio === e.id).length;
            const max = Math.max(1, ...ESTAGIOS.map((x) => vendas.filter((v) => v.estagio === x.id).length));
            if (n === 0) return null;
            return <div key={e.id} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}><span style={{ width: 130, fontSize: 11.5, color: "#5B6B7C", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{e.nome}</span><div style={{ flex: 1, height: 14, background: "#F0F2F6", borderRadius: 4 }}><div style={{ width: `${(n / max) * 100}%`, height: "100%", background: BLOCOS[e.bloco].cor, borderRadius: 4, minWidth: 4 }} /></div><span style={{ width: 28, fontSize: 12, fontWeight: 700, textAlign: "right" }}>{n}</span></div>;
          })}
        </div>
        <div style={{ background: "#fff", border: "1px solid #E2E7EE", borderRadius: 10, padding: 16 }}>
          <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 12 }}>Carga na esteira — {papel === "CREDITO" ? "crédito" : "SV"}</div>
          {Object.entries(porAnalista).sort((a, b) => b[1] - a[1]).map(([a, n]) => <div key={a} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7 }}><span style={{ width: 110, fontSize: 12, color: "#5B6B7C", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a}</span><div style={{ flex: 1, height: 14, background: "#F0F2F6", borderRadius: 4 }}><div style={{ width: `${(n / maxA) * 100}%`, height: "100%", background: papel === "CREDITO" ? "#7C5CBF" : "#2456A6", borderRadius: 4, minWidth: 4 }} /></div><span style={{ width: 24, fontSize: 12, fontWeight: 700, textAlign: "right" }}>{n}</span></div>)}
          {Object.keys(porAnalista).length === 0 && <div style={{ fontSize: 12.5, color: "#8B99A9" }}>Sem vendas na esteira.</div>}
        </div>
      </div>
      <div style={{ background: "#fff", border: "1px solid #E2E7EE", borderRadius: 10, padding: 16, marginTop: 14 }}>
        <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 10 }}>Há mais tempo paradas na esteira</div>
        {paradas.length === 0 && <div style={{ fontSize: 12.5, color: "#8B99A9" }}>Esteira limpa.</div>}
        {paradas.map((v) => <div key={v.id} onClick={() => abrir(v)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderTop: "1px solid #EEF1F5", cursor: "pointer", fontSize: 13 }}><span style={{ width: 9, height: 9, borderRadius: 2, background: corEst(v.estagio), flexShrink: 0 }} /><span style={{ fontWeight: 600, flex: 1 }}>{v.cliente || "(sem nome)"}</span><span style={{ color: "#5B6B7C", fontSize: 12 }}>{estDef(v.estagio).nome}</span><span style={{ fontWeight: 700, color: diasParado(v.data_estagio) > 5 ? "#B03A3A" : "#5B6B7C", fontSize: 12 }}>{diasParado(v.data_estagio)}d</span></div>)}
      </div>
    </div>
  );
}

// ============================================================
// NOVA VENDA
// ============================================================
function NovaVenda({ analistas, onCriar }) {
  const vazio = { cliente: "", cpf: "", codigo: "", processo: "", empreendimento: "", unidade: "", tipologia: "", cat_uso: "", vlr_venda: "", vlr_avaliacao: "", renda: "", corretor: "", gerente: "", banco: "", garantia: "", analista_sv: "", analista_credito: "", estagio: "CP_ANALISANDO", obs: "" };
  const [f, setF] = useState(vazio);
  const campo = (k, r) => <div><label style={S.label}>{r}</label><input value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} style={S.input} /></div>;
  return (
    <div style={{ padding: 16, maxWidth: 680 }}>
      <div style={{ background: "#fff", border: "1px solid #E2E7EE", borderRadius: 10, padding: 20 }}>
        <div style={{ fontWeight: 800, fontSize: 16, marginBottom: 16 }}>Cadastrar venda</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {campo("cliente", "Cliente *")}{campo("cpf", "CPF")}{campo("codigo", "Chave (CHV)")}{campo("processo", "Nº processo")}
          {campo("empreendimento", "Empreendimento")}{campo("unidade", "Unidade")}{campo("tipologia", "Tipologia")}{campo("cat_uso", "Cat. uso (HIS)")}
          {campo("vlr_venda", "Valor da venda")}{campo("vlr_avaliacao", "Valor de avaliação")}{campo("renda", "Renda")}{campo("banco", "Banco")}
          {campo("corretor", "Corretor(a)")}{campo("gerente", "Gerente")}
          <div><label style={S.label}>Estágio inicial</label><select value={f.estagio} onChange={(e) => setF({ ...f, estagio: e.target.value })} style={S.input}>{Object.keys(BLOCOS).map((b) => <optgroup key={b} label={BLOCOS[b].nome}>{ESTAGIOS.filter((e) => e.bloco === b).map((e) => <option key={e.id} value={e.id}>{e.nome}</option>)}</optgroup>)}</select></div>
          <div><label style={S.label}>Analista SV</label><select value={f.analista_sv} onChange={(e) => setF({ ...f, analista_sv: e.target.value })} style={S.input}><option value="">—</option>{analistas.map((a) => <option key={a} value={a}>{a}</option>)}</select></div>
          <div style={{ gridColumn: "1 / -1" }}><label style={S.label}>Observações</label><textarea value={f.obs} onChange={(e) => setF({ ...f, obs: e.target.value })} rows={2} style={{ ...S.input, resize: "vertical" }} /></div>
        </div>
        <button onClick={() => { onCriar(f); setF(vazio); }} style={{ ...S.btn(), marginTop: 16 }}>Cadastrar venda</button>
      </div>
    </div>
  );
}

// ============================================================
// IMPORTAR — entende as duas planilhas (SV e Crédito)
// ============================================================
const MAPA_AUTO = [
  ["cliente", ["cliente", "nome"]],
  ["cpf", ["cpf"]],
  ["codigo", ["chave", "chv"]],
  ["processo", ["processo"]],
  ["link", ["link"]],
  ["empreendimento", ["empreendimento", "empreend"]],
  ["unidade", ["unidade", "unid"]],
  ["tipologia", ["tipologia"]],
  ["cat_uso", ["cat. uso", "cat uso", "categoria", "his"]],
  ["m2", ["m²", "m2", "area"]],
  ["vlr_venda", ["vlrvenda", "valor venda", "vlr venda"]],
  ["vlr_avaliacao", ["avaliação", "avaliacao", "valor avalia"]],
  ["renda", ["renda"]],
  ["banco", ["banco"]],
  ["diferenca", ["diferença", "diferenca"]],
  ["repasse", ["repasse"]],
  ["melhoria", ["melhoria"]],
  ["politica", ["política", "politica"]],
  ["garantia", ["garantia"]],
  ["dependente", ["dependente"]],
  ["erros", ["erros"]],
  ["resultado", ["resultado"]],
  ["corretor", ["corretor", "parceiro", "vendedor"]],
  ["gerente", ["gerente"]],
  ["gestor", ["gestor"]],
  ["diretor", ["diretor"]],
  ["data_contrato", ["data de contrato", "data contrato"]],
  ["semana", ["semana"]],
  ["analista_sv", ["analista de sv", "analista sv", "analista de vendas"]],
  ["analista_credito", ["analista de crédito", "analista credito", "analista de credito"]],
  ["assistente_credito", ["assistente de crédito", "assistente credito"]],
  ["estagio", ["estagio", "estágio"]],
];
const CAMPOS = MAPA_AUTO.map(([c]) => c);
const ROTULO = { cliente: "Cliente", cpf: "CPF", codigo: "Chave", processo: "Nº processo", link: "Link", empreendimento: "Empreendimento", unidade: "Unidade", tipologia: "Tipologia", cat_uso: "Cat. uso", m2: "M²", vlr_venda: "Valor venda", vlr_avaliacao: "Valor avaliação", renda: "Renda", banco: "Banco", diferenca: "Diferença", repasse: "Repasse", melhoria: "Melhoria", politica: "Política créd.", garantia: "Garantia", dependente: "Dependente", erros: "Erros", resultado: "Resultado", corretor: "Corretor", gerente: "Gerente", gestor: "Gestor", diretor: "Diretor", data_contrato: "Data contrato", semana: "Semana", analista_sv: "Analista SV", analista_credito: "Analista créd.", assistente_credito: "Assist. créd.", estagio: "Estágio" };

function mapearEstagio(txt) {
  if (!txt) return "CP_ANALISANDO";
  const t = String(txt).toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const tabela = [
    ["VALIDADO CEF", "SV_VALIDADO_CEF"], ["VALIDADO DIRETO", "SV_VALIDADO_DIRETO"], ["VALIDADO/NR", "SV_VALIDADO_DIRETO"],
    ["AGUARDANDO ASSINATURA", "V_AG_ASSINATURA"], ["COMPLETO E VALIDADO", "V_COMPLETO_VALIDADO"], ["AGUARDANDO COMPLETO", "V_AG_COMPLETO_VALID"],
    ["DEVOLVIDO COM PENDENCIA CCA", "V_DEV_PEND_CCA"], ["DEVOLVIDO COM PENDENCIA COMERCIAL", "V_DEV_PEND_COMERCIAL"],
    ["TRIAGEM DEVOLVIDA", "V_TRIAGEM_DEV_PEND"], ["TRIAGEM CONTRATOS", "V_TRIAGEM_CONTRATOS"], ["TRIAGEM DE CONTRATOS", "V_TRIAGEM_CONTRATOS"],
    ["SOLICITANDO DOCS", "V_CREDITO_SOLIC_DOCS"], ["CREDITO SOLICITANDO", "V_CREDITO_SOLIC_DOCS"], ["CONTRATO 100", "V_CONTRATO_100"],
    ["ANALISANDO CONTRATO", "CP_ANALISANDO"], ["AGUARDANDO SICAQ LEAD", "CP_AG_SICAQ_LEAD"], ["CCA - APROVADO", "CP_CCA_APROVADO"], ["CCA - PENDENCIA", "CP_CCA_PENDENCIA"],
    ["FALTA DOCUMENTACAO - CEF", "CP_FALTA_DOC_CEF"], ["LEAD APROVADO", "CP_LEAD_AG_SINAL"], ["SINAL PAGO", "CP_SINAL_AG_SICAQ"], ["FALTA DOCUMENTACAO - VENDA DIRETA", "CP_FALTA_DOC_VD"],
    ["DESISTENCIA", "DESISTENCIA"], ["RESTRICAO", "RESTRICAO"],
  ];
  for (const [chave, id] of tabela) if (t.includes(chave)) return id;
  return "CP_ANALISANDO";
}

function Importar({ onImportar }) {
  const [linhas, setLinhas] = useState(null);
  const [colunas, setColunas] = useState([]);
  const [mapa, setMapa] = useState({});
  const [erro, setErro] = useState("");
  const [nomeArq, setNomeArq] = useState("");

  const lerArquivo = (file) => {
    setErro(""); setNomeArq(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: "array" });
        let melhor = null, n = 0;
        wb.SheetNames.forEach((nm) => { const j = XLSX.utils.sheet_to_json(wb.Sheets[nm], { defval: "" }); if (j.length > n) { melhor = j; n = j.length; } });
        if (!melhor || !melhor.length) return setErro("Não encontrei linhas de dados.");
        const cols = Object.keys(melhor[0]);
        const m = {};
        CAMPOS.forEach((campo) => { const alvos = MAPA_AUTO.find(([c]) => c === campo)[1]; const achada = cols.find((col) => alvos.some((a) => col.toLowerCase().replace(/\s|\./g, " ").includes(a))); if (achada) m[campo] = achada; });
        setLinhas(melhor); setColunas(cols); setMapa(m);
      } catch { setErro("Não consegui ler. Use .xlsx ou .csv."); }
    };
    reader.readAsArrayBuffer(file);
  };

  const importar = () => {
    if (!mapa.cliente) return setErro("Mapeie ao menos a coluna Cliente.");
    const validas = []; let rej = 0;
    linhas.forEach((l) => {
      const d = {};
      CAMPOS.forEach((c) => { if (mapa[c]) d[c] = String(l[mapa[c]] ?? "").trim(); });
      if (!d.cliente) { rej++; return; }
      ["vlr_venda", "vlr_avaliacao", "renda"].forEach((k) => { if (d[k]) d[k] = d[k].replace(/[R$\s.]/g, "").replace(",", "."); });
      d.estagio = mapearEstagio(d.estagio);
      validas.push(d);
    });
    if (!validas.length) return setErro("Nenhuma linha válida.");
    onImportar(validas);
    if (rej) alert(`${rej} linha(s) sem cliente foram ignoradas.`);
  };

  return (
    <div style={{ padding: 16, maxWidth: 820 }}>
      <div style={{ background: "#fff", border: "1px solid #E2E7EE", borderRadius: 10, padding: 20 }}>
        <div style={{ fontWeight: 800, fontSize: 16 }}>Importar planilha</div>
        <p style={{ fontSize: 13, color: "#5B6B7C" }}>Funciona com as <b>duas</b> planilhas (a de SV e a de Crédito). Suba uma de cada vez — o sistema reconhece as colunas de cada uma e mapeia o estágio automaticamente. Pode importar a segunda depois.</p>
        <input type="file" accept=".xlsx,.xls,.csv" onChange={(e) => e.target.files[0] && lerArquivo(e.target.files[0])} style={{ fontSize: 13 }} />
        {erro && <div style={{ marginTop: 10, color: "#B03A3A", fontSize: 13, fontWeight: 600 }}>{erro}</div>}
        {linhas && (
          <div style={{ marginTop: 18 }}>
            <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 8 }}>{nomeArq} · {linhas.length} linha(s) · confira o mapeamento</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(200px,1fr))", gap: 10 }}>
              {CAMPOS.map((campo) => (
                <div key={campo}><label style={S.label}>{ROTULO[campo]}{campo === "cliente" ? " *" : ""}</label>
                  <select value={mapa[campo] || ""} onChange={(e) => setMapa({ ...mapa, [campo]: e.target.value })} style={{ ...S.input, fontSize: 12 }}>
                    <option value="">— não importar —</option>
                    {colunas.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              ))}
            </div>
            <button onClick={importar} style={{ ...S.btn(), marginTop: 16 }}>Importar {linhas.length} venda(s)</button>
          </div>
        )}
      </div>
    </div>
  );
}
