# Esteira de Vendas — sistema pronto para publicar

CRM da Secretaria de Vendas + Crédito (validação de contratos MCMV). Kanban e lista, dois times (SV e Crédito), checklists, pendências, análise por IA, painel e importação das planilhas.

## O jeito mais rápido de colocar no ar (recomendado)

Não precisa instalar nada no seu computador. Use a Vercel:

1. Crie uma conta grátis em vercel.com
2. Instale a CLI: no terminal, rode `npm i -g vercel`
3. Dentro desta pasta, rode `vercel`
4. Responda as perguntas (pode aceitar tudo no padrão). Em segundos ele te dá um link público.

Pronto — o time acessa pelo link. Para um domínio próprio (ex.: esteira.suaempresa.com.br), é só adicionar nas configurações do projeto na Vercel.

Alternativa por arrastar-e-soltar: rode `npm install` e `npm run build` nesta pasta, depois arraste a pasta `dist` gerada para vercel.com/new ou app.netlify.com/drop.

## Rodar no seu computador para testar antes

```
npm install
npm run dev
```
Abre em http://localhost:5173

## Configurações (todas opcionais)

O sistema **já funciona sem configurar nada** — nesse modo, os dados ficam salvos no navegador de cada pessoa (ótimo para testar). Para liberar os dois recursos abaixo, copie `.env.example` para `.env` e preencha.

### 1. Dados compartilhados entre o time
Para todos verem a MESMA esteira (e não cópias separadas):
1. Crie conta grátis em jsonbin.io
2. No painel, vá em **API Keys** e copie a **Master Key**
3. Crie um **Bin** novo com o conteúdo `{"vendas":[],"analistas":[]}` e copie o **Bin ID** (aparece na URL)
4. Na Vercel, em Settings → Environment Variables, adicione:
   - `VITE_JSONBIN_BIN_ID` = o Bin ID
   - `VITE_JSONBIN_KEY` = a Master Key
5. Refaça o deploy (`vercel --prod`)

### 2. Análise por IA
O botão "Analisar com IA" precisa de uma chave da Anthropic:
1. Crie a chave em console.anthropic.com
2. Na Vercel, em Settings → Environment Variables, adicione:
   - `ANTHROPIC_API_KEY` = sua chave
   (esta NÃO leva o prefixo VITE_ — fica só no servidor, protegida)
3. Refaça o deploy

Sem essa chave, o resto do sistema funciona normalmente; só o botão de IA fica inativo.

## Como o time usa

- **Importar**: suba a planilha de SV e a de Crédito (uma de cada vez). O sistema reconhece as colunas e distribui as vendas nos estágios certos.
- **Kanban**: arraste os cartões entre as fases da esteira.
- **Lista**: veja todas as vendas, incluindo as de Comercial Proposta, com filtro por estágio.
- **Botão SV / Crédito** (topo): troca a visão entre os dois times.
- Cada um seleciona o próprio nome em "quem usa" para o histórico registrar as ações.

## Importante sobre dados (LGPD)

A base tem CPF e renda. Com o jsonbin, os dados ficam no serviço deles — para dados sensíveis em produção, o ideal é um backend próprio (posso te ajudar a migrar para Supabase quando quiser). O CPF já aparece mascarado nas listagens.

## Estrutura do projeto

```
esteira/
├── index.html
├── package.json
├── vite.config.js
├── .env.example          → copie para .env e preencha (opcional)
├── api/
│   └── analisar.js       → função da IA (chave protegida no servidor)
└── src/
    ├── main.jsx
    ├── Esteira.jsx       → o sistema inteiro
    └── storage.js        → camada de dados (nuvem ou navegador)
```
