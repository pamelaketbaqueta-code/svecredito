// Função serverless (Vercel) — análise por IA com a chave protegida no servidor.
// A chave ANTHROPIC_API_KEY é configurada nas variáveis de ambiente da Vercel,
// nunca aparece no navegador.

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ erro: "use POST" });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(200).json({ erro: "IA não configurada (defina ANTHROPIC_API_KEY)" });

  try {
    const { payload } = req.body;
    const prompt =
      `Você é analista sênior de validação de contratos imobiliários MCMV (times de Secretaria de Vendas e de Crédito). ` +
      `Analise a venda e responda APENAS JSON {"risco":"baixo"|"medio"|"alto","pendencias_provaveis":["..."],"resumo":"..."}. ` +
      `Verifique: divergência ANAPRO×UAU, diferença entre valor de venda e avaliação, renda × faixa (HIS-1 até 4.863, HIS-2 até 9.726), ` +
      `SICAQ incompleto/vencido, garantia/política de crédito, campos críticos vazios (CPF, valores, unidade), itens do checklist em VERIFICAR. ` +
      `Resumo em até 3 frases, português.\n\nDADOS:\n${JSON.stringify(payload)}`;

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }],
      }),
    });
    const data = await r.json();
    return res.status(200).json(data);
  } catch (e) {
    return res.status(200).json({ erro: "falha na análise" });
  }
}
