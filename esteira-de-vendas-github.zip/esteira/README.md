# Esteira de Vendas

Sistema de validação de contratos imobiliários (MCMV) para os times de **Secretaria de Vendas** e **Crédito**. Substitui a planilha de controle por uma esteira organizada: Kanban e lista, checklists por time, pendências, painel de carga e análise por IA.

> Os times não vendem — recebem a venda pronta, conferem documentação, cadastro, contrato, avaliação e crédito, apontam pendências e liberam para validação (CEF / direto).

## Recursos

- **Kanban** dos estágios da esteira (arraste para mover) + **Lista** com todos os 25 estágios agrupados em Comercial Proposta, Venda na esteira e Validadas
- **Dois times** num botão: Secretaria de Vendas e Crédito, cada um com seus campos e checklist
- **Checklists** com as regras reais de validação (17 itens de SV, 10 de Crédito)
- **Pendências** por venda, com devolução em um clique
- **Análise por IA** que aponta risco e prováveis problemas antes da validação
- **Painel** com vendas por estágio, carga por analista e itens parados há mais tempo
- **Importação** das planilhas atuais (SV e Crédito) com mapeamento automático de colunas
- **Histórico** de quem mexeu em cada venda

## Deploy em 1 clique

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/SEU-USUARIO/esteira-de-vendas)

> Troque `SEU-USUARIO` pelo seu usuário do GitHub depois de subir o repositório.

## Rodando localmente

```bash
npm install
npm run dev
```
Abre em http://localhost:5173

Para gerar a versão de produção:
```bash
npm run build
npm run preview
```

## Configuração (opcional)

O sistema **funciona sem nenhuma configuração** — nesse modo salva no navegador de cada usuário (ideal para testar). Copie `.env.example` para `.env` para habilitar:

| Variável | Para quê |
|---|---|
| `VITE_JSONBIN_BIN_ID` e `VITE_JSONBIN_KEY` | Dados **compartilhados** entre o time (conta grátis em [jsonbin.io](https://jsonbin.io)) |
| `ANTHROPIC_API_KEY` | Botão **Analisar com IA** (chave de [console.anthropic.com](https://console.anthropic.com)) — configure no painel da Vercel, fica protegida no servidor |

Passo a passo detalhado de cada uma em [`LEIA-ME.md`](./LEIA-ME.md).

## Estrutura

```
esteira-de-vendas/
├── api/
│   └── analisar.js        # função serverless da IA (chave protegida)
├── src/
│   ├── Esteira.jsx        # o sistema inteiro
│   ├── storage.js         # camada de dados (nuvem ou navegador)
│   └── main.jsx           # ponto de entrada
├── index.html
├── package.json
├── vite.config.js
└── vercel.json            # roteamento do app + API
```

## Sobre dados sensíveis (LGPD)

A base contém CPF e renda. O CPF aparece mascarado nas listagens. Para produção com dados reais, recomenda-se um backend próprio com login (ex.: Supabase) em vez do jsonbin. O modo navegador e o jsonbin servem para validar o fluxo com o time.

## Licença

MIT — veja [LICENSE](./LICENSE).
