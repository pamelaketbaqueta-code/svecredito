# Como subir ao GitHub e publicar

O projeto já vem com o Git inicializado e o primeiro commit feito. Você só precisa enviar para o GitHub.

## 1. Crie o repositório no GitHub

1. Acesse github.com/new
2. Nome: `esteira-de-vendas` (ou outro)
3. Deixe **vazio** (sem README, sem .gitignore, sem licença — o projeto já tem)
4. Clique em **Create repository**

## 2. Envie o projeto

No terminal, dentro desta pasta, rode (troque SEU-USUARIO):

```bash
git remote add origin https://github.com/SEU-USUARIO/esteira-de-vendas.git
git branch -M main
git push -u origin main
```

Se pedir login, use seu usuário do GitHub e um **token** no lugar da senha (github.com → Settings → Developer settings → Personal access tokens).

> O Git já está inicializado e com um commit pronto. Se quiser começar do zero, apague a pasta `.git` e rode `git init` de novo.

## 3. Publique na Vercel (conectando o GitHub)

1. Acesse vercel.com e entre com sua conta do GitHub
2. **Add New → Project** → escolha o repositório `esteira-de-vendas`
3. A Vercel detecta o Vite sozinho — clique em **Deploy**
4. Em segundos você tem o link público

A partir daí, todo `git push` atualiza o site automaticamente.

### Variáveis (opcionais) na Vercel

Em **Settings → Environment Variables**:
- `VITE_JSONBIN_BIN_ID` e `VITE_JSONBIN_KEY` → dados compartilhados entre o time
- `ANTHROPIC_API_KEY` → botão de análise por IA

Depois de adicionar, clique em **Redeploy**. Detalhes no `LEIA-ME.md`.

## Pronto

Sem nenhuma variável, o sistema já funciona (salvando no navegador). As variáveis só ligam o compartilhamento e a IA.
