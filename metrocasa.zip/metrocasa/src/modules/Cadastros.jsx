import React, { useState } from "react";
import { PERFIS, PERFIL_NOME } from "../lib/defs";
import { S, Vazio } from "../components/ui";
import { api } from "../lib/api";

// Define os campos de cada tabela de cadastro
const SCHEMAS = {
  corretores: { titulo: "Corretores", campos: [["nome", "Nome"], ["telefone", "Telefone"], ["email", "E-mail"], ["gerente", "Gerente"]] },
  gerentes: { titulo: "Gerentes", campos: [["nome", "Nome"], ["email", "E-mail"], ["diretor", "Diretor"]] },
  diretores: { titulo: "Diretores", campos: [["nome", "Nome"], ["email", "E-mail"]] },
  analistas: { titulo: "Analistas", campos: [["nome", "Nome"], ["email", "E-mail"], ["area", "Área (SV/CREDITO/ASSISTENTE)"]] },
  empreendimentos: { titulo: "Empreendimentos", campos: [["nome", "Nome"], ["cidade", "Cidade"], ["tipologia", "Tipologia"], ["total_unidades", "Total unidades"]] },
  bancos: { titulo: "Bancos", campos: [["nome", "Nome"]] },
  motivos_distrato: { titulo: "Motivos de distrato", campos: [["nome", "Motivo"]] },
  tipos_pendencia: { titulo: "Tipos de pendência", campos: [["nome", "Tipo"]] },
};

// no módulo "Configurações" (tabela __config) mostramos várias tabelas de cadastro + usuários
const CONFIG_TABELAS = ["analistas", "gerentes", "diretores", "bancos", "motivos_distrato", "tipos_pendencia"];

export default function Cadastros({ db, dark, salvar, excluir, avisar, usuario, tabela }) {
  if (tabela === "__config") {
    return (
      <div style={{ padding: 16 }}>
        <h2 style={{ margin: "0 0 14px", fontSize: 20 }}>Configurações</h2>
        <Usuarios dark={dark} avisar={avisar} usuarioAtual={usuario} />
        {CONFIG_TABELAS.map((t) => <CadastroTabela key={t} db={db} dark={dark} salvar={salvar} excluir={excluir} avisar={avisar} tabela={t} compacto />)}
      </div>
    );
  }
  return (
    <div style={{ padding: 16 }}>
      <CadastroTabela db={db} dark={dark} salvar={salvar} excluir={excluir} avisar={avisar} tabela={tabela} />
    </div>
  );
}

function CadastroTabela({ db, dark, salvar, excluir, avisar, tabela, compacto }) {
  const schema = SCHEMAS[tabela];
  const [f, setF] = useState({});
  const itens = db[tabela] || [];
  if (!schema) return null;

  const add = async () => {
    if (!f.nome || !f.nome.trim()) return avisar("Informe o nome", true);
    await salvar(tabela, { ...f, ativo: "SIM" });
    setF({});
    avisar("Cadastrado");
  };

  return (
    <div style={{ ...S.card(dark), padding: 16, marginBottom: 16 }}>
      <div style={{ fontWeight: 700, fontSize: compacto ? 14 : 18, marginBottom: 12 }}>{schema.titulo}</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
        {schema.campos.map(([k, r]) => (
          <input key={k} placeholder={r} value={f[k] || ""} onChange={(e) => setF({ ...f, [k]: e.target.value })} style={{ ...S.input(dark), width: k === "nome" ? 200 : 150 }} />
        ))}
        <button onClick={add} style={S.btn()}>Adicionar</button>
      </div>
      {itens.length === 0 ? <div style={{ fontSize: 12.5, color: "#8B99A9" }}>Nenhum cadastro.</div> : (
        <div style={{ overflowX: "auto" }}>
          <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 13 }}>
            <thead><tr style={{ textAlign: "left", color: "#8B99A9", fontSize: 11 }}>{schema.campos.map(([k, r]) => <th key={k} style={{ padding: "6px 8px", textTransform: "uppercase" }}>{r}</th>)}<th></th></tr></thead>
            <tbody>
              {itens.map((it) => (
                <tr key={it.id} style={{ borderTop: `1px solid ${dark ? "#222B36" : "#F0F2F6"}` }}>
                  {schema.campos.map(([k]) => <td key={k} style={{ padding: "7px 8px" }}>{it[k] || "—"}</td>)}
                  <td style={{ padding: "7px 8px", textAlign: "right" }}><button onClick={() => excluir(tabela, it.id)} style={{ background: "transparent", border: "none", color: "#B03A3A", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>excluir</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function Usuarios({ dark, avisar, usuarioAtual }) {
  const [lista, setLista] = useState(null);
  const [f, setF] = useState({ nome: "", email: "", senha: "", perfil: "COMERCIAL" });

  const carregar = async () => {
    if (api.modo === "demo") { setLista([]); return; }
    const r = await fetch(import.meta.env.VITE_API_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: import.meta.env.VITE_API_TOKEN, action: "usuarios" }) });
    const j = await r.json();
    setLista(j.items || []);
  };
  React.useEffect(() => { carregar(); }, []);

  const add = async () => {
    if (api.modo === "demo") return avisar("Conecte o Sheets para gerenciar usuários", true);
    if (!f.email.trim() || !f.senha.trim()) return avisar("E-mail e senha obrigatórios", true);
    await fetch(import.meta.env.VITE_API_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: import.meta.env.VITE_API_TOKEN, action: "saveUsuario", item: { ...f, ativo: "SIM" } }) });
    setF({ nome: "", email: "", senha: "", perfil: "COMERCIAL" });
    avisar("Usuário criado");
    carregar();
  };

  return (
    <div style={{ ...S.card(dark), padding: 16, marginBottom: 16 }}>
      <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 4 }}>Usuários e perfis de acesso</div>
      <div style={{ fontSize: 12, color: "#8B99A9", marginBottom: 12 }}>Cada perfil enxerga apenas seus módulos. {api.modo === "demo" ? "Disponível ao conectar o Google Sheets." : ""}</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
        <input placeholder="Nome" value={f.nome} onChange={(e) => setF({ ...f, nome: e.target.value })} style={{ ...S.input(dark), width: 170 }} />
        <input placeholder="E-mail" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} style={{ ...S.input(dark), width: 190 }} />
        <input placeholder="Senha" value={f.senha} onChange={(e) => setF({ ...f, senha: e.target.value })} style={{ ...S.input(dark), width: 130 }} />
        <select value={f.perfil} onChange={(e) => setF({ ...f, perfil: e.target.value })} style={{ ...S.input(dark), width: 180 }}>{PERFIS.map((p) => <option key={p} value={p}>{PERFIL_NOME[p]}</option>)}</select>
        <button onClick={add} style={S.btn()}>Criar usuário</button>
      </div>
      {lista && lista.length > 0 && (
        <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 13 }}>
          <thead><tr style={{ textAlign: "left", color: "#8B99A9", fontSize: 11 }}><th style={{ padding: "6px 8px" }}>NOME</th><th style={{ padding: "6px 8px" }}>E-MAIL</th><th style={{ padding: "6px 8px" }}>PERFIL</th></tr></thead>
          <tbody>{lista.map((u) => <tr key={u.id} style={{ borderTop: `1px solid ${dark ? "#222B36" : "#F0F2F6"}` }}><td style={{ padding: "7px 8px" }}>{u.nome}</td><td style={{ padding: "7px 8px" }}>{u.email}</td><td style={{ padding: "7px 8px" }}>{PERFIL_NOME[u.perfil] || u.perfil}</td></tr>)}</tbody>
        </table>
      )}
    </div>
  );
}
