import React from "react";
import { ETAPAS, ESTAGIOS, estDef, etapaDe, diasParado, fmtBRL, CORES } from "../lib/defs";
import { Card, Barras, S } from "../components/ui";

export default function Dashboard({ db, dark, abrirVenda }) {
  const vendas = db.vendas || [];
  const distratos = db.distratos || [];
  const pendencias = (db.pendencias || []).filter((p) => String(p.resolvida).toUpperCase() !== "SIM" && p.resolvida !== true);

  const naEtapa = (et) => vendas.filter((v) => estDef(v.estagio).etapa === et).length;
  const validadas = vendas.filter((v) => ["A_VALIDADO_CEF", "A_VALIDADO_DIRETO", "E_CONCLUIDO"].includes(v.estagio));
  const canceladas = vendas.filter((v) => v.estagio === "X_CANCELADO");
  const assinaturasPend = vendas.filter((v) => ["S_AG_ASSINATURA", "A_ENVIADO", "A_ASS_CLIENTE"].includes(v.estagio));

  const ativas = vendas.filter((v) => !["E_CONCLUIDO", "X_CANCELADO", "X_DISTRATO"].includes(v.estagio));
  const tempoMedio = ativas.length ? Math.round(ativas.reduce((s, v) => s + diasParado(v.data_estagio), 0) / ativas.length) : 0;

  // SLA por etapa (tempo médio parado por etapa)
  const slaPorEtapa = Object.keys(ETAPAS).filter((e) => !["ENTREGA", "ENCERRADO"].includes(e)).map((et) => {
    const vs = vendas.filter((v) => estDef(v.estagio).etapa === et && !["E_CONCLUIDO", "X_CANCELADO", "X_DISTRATO"].includes(v.estagio));
    const media = vs.length ? Math.round(vs.reduce((s, v) => s + diasParado(v.data_estagio), 0) / vs.length) : 0;
    return { nome: ETAPAS[et].nome, valor: media, cor: ETAPAS[et].cor };
  });

  // ranking analistas (SV + crédito) por vendas validadas
  const rankAnalistas = {};
  validadas.forEach((v) => { [v.analista_sv, v.analista_credito].forEach((a) => { if (a) rankAnalistas[a] = (rankAnalistas[a] || 0) + 1; }); });
  const rankAnalistasArr = Object.entries(rankAnalistas).map(([nome, valor]) => ({ nome, valor })).sort((a, b) => b.valor - a.valor).slice(0, 8);

  const rankCorretores = {};
  vendas.forEach((v) => { if (v.corretor) rankCorretores[v.corretor] = (rankCorretores[v.corretor] || 0) + 1; });
  const rankCorretoresArr = Object.entries(rankCorretores).map(([nome, valor]) => ({ nome, valor })).sort((a, b) => b.valor - a.valor).slice(0, 8);

  const porEmpreend = {};
  vendas.forEach((v) => { const e = v.empreendimento || "—"; porEmpreend[e] = (porEmpreend[e] || 0) + 1; });
  const porEmpreendArr = Object.entries(porEmpreend).map(([nome, valor]) => ({ nome, valor })).sort((a, b) => b.valor - a.valor).slice(0, 10);

  const cardsEstagio = Object.keys(ETAPAS).filter((e) => e !== "ENCERRADO").map((et) => ({ nome: ETAPAS[et].nome, valor: naEtapa(et), cor: ETAPAS[et].cor }));

  return (
    <div style={{ padding: 16 }}>
      <h2 style={{ margin: "0 0 14px", fontSize: 20 }}>Dashboard</h2>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 14 }}>
        <Card dark={dark} titulo="Total de vendas" valor={vendas.length} />
        <Card dark={dark} titulo="Em crédito" valor={naEtapa("CREDITO")} cor={ETAPAS.CREDITO.cor} />
        <Card dark={dark} titulo="Em secretaria" valor={naEtapa("SECRETARIA")} cor={ETAPAS.SECRETARIA.cor} />
        <Card dark={dark} titulo="Pendências" valor={pendencias.length} cor="#C77E1B" />
        <Card dark={dark} titulo="Assin. pendentes" valor={assinaturasPend.length} cor={ETAPAS.ASSINATURA.cor} />
      </div>
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 18 }}>
        <Card dark={dark} titulo="Distratos" valor={distratos.length} cor="#B03A3A" />
        <Card dark={dark} titulo="Validadas" valor={validadas.length} cor="#2E8B57" />
        <Card dark={dark} titulo="Canceladas" valor={canceladas.length} cor="#B03A3A" />
        <Card dark={dark} titulo="Tempo médio esteira" valor={`${tempoMedio}d`} />
        <Card dark={dark} titulo="Em comercial" valor={naEtapa("COMERCIAL")} cor={ETAPAS.COMERCIAL.cor} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))", gap: 14 }}>
        <Painel dark={dark} titulo="Vendas por etapa"><Barras dark={dark} dados={cardsEstagio} /></Painel>
        <Painel dark={dark} titulo="SLA por etapa (dias médios parado)"><Barras dark={dark} dados={slaPorEtapa} /></Painel>
        <Painel dark={dark} titulo="Ranking de analistas (validadas)"><Barras dark={dark} dados={rankAnalistasArr} /></Painel>
        <Painel dark={dark} titulo="Ranking de corretores"><Barras dark={dark} dados={rankCorretoresArr} /></Painel>
        <Painel dark={dark} titulo="Vendas por empreendimento"><Barras dark={dark} dados={porEmpreendArr} /></Painel>
      </div>
    </div>
  );
}

function Painel({ dark, titulo, children }) {
  return (
    <div style={{ ...S.card(dark), padding: 16 }}>
      <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 12 }}>{titulo}</div>
      {children}
    </div>
  );
}
