import React, { useState } from "react";
import { api } from "../lib/api";
import { CORES } from "../lib/defs";
import { S } from "../components/ui";

export default function Login({ onEntrar }) {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [carregando, setCarregando] = useState(false);

  const entrar = async () => {
    setErro(""); setCarregando(true);
    try {
      const r = await api.login(email, senha);
      if (r.ok) onEntrar(r.usuario);
      else setErro(r.error || "Não foi possível entrar");
    } catch { setErro("Falha de conexão"); }
    setCarregando(false);
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: CORES.cinza, fontFamily: "'Segoe UI',system-ui,sans-serif", padding: 16 }}>
      <div style={{ width: 360, background: "#fff", borderRadius: 14, boxShadow: "0 10px 40px rgba(0,0,0,.12)", overflow: "hidden" }}>
        <div style={{ background: CORES.primary, padding: "26px 24px", color: "#fff" }}>
          <div style={{ fontWeight: 800, fontSize: 22, letterSpacing: 1 }}>METROCASA</div>
          <div style={{ fontSize: 12.5, opacity: 0.9, marginTop: 2 }}>Gestão de Vendas e Contratos</div>
        </div>
        <div style={{ padding: 24 }}>
          <label style={S.label()}>E-mail</label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => e.key === "Enter" && entrar()} style={{ ...S.input(), marginBottom: 12 }} placeholder="seu@metrocasa.com" />
          <label style={S.label()}>Senha</label>
          <input type="password" value={senha} onChange={(e) => setSenha(e.target.value)} onKeyDown={(e) => e.key === "Enter" && entrar()} style={{ ...S.input(), marginBottom: 16 }} placeholder="••••••" />
          {erro && <div style={{ color: "#B03A3A", fontSize: 12.5, fontWeight: 600, marginBottom: 12 }}>{erro}</div>}
          <button onClick={entrar} disabled={carregando} style={{ ...S.btn(), width: "100%", padding: "10px", opacity: carregando ? 0.6 : 1 }}>{carregando ? "Entrando…" : "Entrar"}</button>
          {api.modo === "demo" && <div style={{ fontSize: 11, color: "#8B99A9", marginTop: 14, textAlign: "center", lineHeight: 1.5 }}>Modo demonstração: qualquer e-mail entra como Administrador. Conecte o Google Sheets para login real.</div>}
        </div>
      </div>
    </div>
  );
}
