import React, { useState } from "react";
import { ESTAGIOS, ETAPAS } from "../lib/defs";
import { S } from "../components/ui";

export default function NovaVenda({ db, dark, salvar, registrarHistorico, avisar, irPara }) {
  const vazio = { cliente: "", cpf: "", telefone: "", email: "", empreendimento: "", unidade: "", tipologia: "", renda: "", vlr_venda: "", vlr_avaliacao: "", banco: "", corretor: "", gerente: "", diretor: "", categoria: "", data_contrato: "", link: "", estagio: "C_PROPOSTA", obs: "" };
  const [f, setF] = useState(vazio);

  const campo = (k, r, tipo = "text") => (
    <div><label style={S.label()}>{r}</label><input type={tipo} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} style={S.input()} /></div>
  );
  const sel = (k, r, tabela, prop = "nome") => (
    <div><label style={S.label()}>{r}</label>
      <input list={`l_${k}`} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} style={S.input()} />
      <datalist id={`l_${k}`}>{(db[tabela] || []).map((x) => <option key={x.id} value={x[prop]} />)}</datalist>
    </div>
  );

  const criar = async () => {
    if (!f.cliente.trim()) return avisar("Informe o cliente", true);
    const id = await salvar("vendas", { ...f, data_estagio: new Date().toISOString(), checklist_sv: "{}", checklist_credito: "{}", documentos: "{}" });
    await registrarHistorico(id, "Venda criada", f.cliente);
    avisar("Venda cadastrada");
    setF(vazio);
    irPara("esteira");
  };

  return (
    <div style={{ padding: 16, maxWidth: 740 }}>
      <h2 style={{ margin: "0 0 14px", fontSize: 20 }}>Nova Venda</h2>
      <div style={{ ...S.card(dark), padding: 20 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {campo("cliente", "Cliente *")}{campo("cpf", "CPF")}{campo("telefone", "Telefone")}{campo("email", "E-mail")}
          {sel("empreendimento", "Empreendimento", "empreendimentos")}{campo("unidade", "Unidade")}{campo("tipologia", "Tipologia")}{campo("categoria", "Categoria (HIS)")}
          {campo("renda", "Renda")}{campo("vlr_venda", "Valor venda")}{campo("vlr_avaliacao", "Valor avaliação")}{sel("banco", "Banco", "bancos")}
          {sel("corretor", "Corretor", "corretores")}{sel("gerente", "Gerente", "gerentes")}{sel("diretor", "Diretor", "diretores")}{campo("data_contrato", "Data contrato", "date")}
          {campo("link", "Link da pasta")}
          <div><label style={S.label()}>Estágio inicial</label><select value={f.estagio} onChange={(e) => setF({ ...f, estagio: e.target.value })} style={S.input()}>{Object.keys(ETAPAS).map((et) => <optgroup key={et} label={ETAPAS[et].nome}>{ESTAGIOS.filter((e) => e.etapa === et).map((e) => <option key={e.id} value={e.id}>{e.nome}</option>)}</optgroup>)}</select></div>
          <div style={{ gridColumn: "1 / -1" }}><label style={S.label()}>Observações</label><textarea value={f.obs} onChange={(e) => setF({ ...f, obs: e.target.value })} rows={2} style={{ ...S.input(), resize: "vertical" }} /></div>
        </div>
        <button onClick={criar} style={{ ...S.btn(), marginTop: 16 }}>Cadastrar venda</button>
      </div>
    </div>
  );
}
