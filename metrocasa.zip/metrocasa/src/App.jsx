import React, { useState, useEffect, useMemo } from "react";
import { api } from "./lib/api";
import { CORES, PERFIL_MODULOS, PERFIL_NOME, ESTAGIOS, estDef, diasParado, parseJSON } from "./lib/defs";
import Login from "./modules/Login";
import Dashboard from "./modules/Dashboard";
import Esteira from "./modules/Esteira";
import DetalheVenda from "./modules/DetalheVenda";
import NovaVenda from "./modules/NovaVenda";
import Distratos from "./modules/Distratos";
import Cadastros from "./modules/Cadastros";
import Relatorios from "./modules/Relatorios";
import ListaSimples from "./modules/ListaSimples";

const MENU = [
  ["dashboard", "Dashboard", "▣"],
  ["nova", "Nova Venda", "＋"],
  ["esteira", "Esteira Comercial", "▤"],
  ["secretaria", "Secretaria de Vendas", "✓"],
  ["credito", "Crédito", "$"],
  ["assinaturas", "Assinaturas", "✎"],
  ["validadas", "Validadas", "★"],
  ["pendencias", "Pendências", "!"],
  ["distratos", "Distratos", "⊘"],
  ["clientes", "Clientes", "☺"],
  ["corretores", "Corretores", "♟"],
  ["empreendimentos", "Empreendimentos", "⌂"],
  ["documentos", "Documentos", "▭"],
  ["relatorios", "Relatórios", "▦"],
  ["configuracoes", "Configurações", "⚙"],
];

export default function App() {
  const [usuario, setUsuario] = useState(null);
  const [db, setDb] = useState(null);
  const [modulo, setModulo] = useState("dashboard");
  const [vendaAberta, setVendaAberta] = useState(null);
  const [busca, setBusca] = useState("");
  const [dark, setDark] = useState(false);
  const [toast, setToast] = useState(null);
  const [carregando, setCarregando] = useState(false);
  const [sidebarAberta, setSidebarAberta] = useState(false);

  useEffect(() => { const u = localStorage.getItem("metrocasa_user"); if (u) setUsuario(JSON.parse(u)); }, []);
  useEffect(() => { if (usuario) carregar(); }, [usuario]);

  const carregar = async () => {
    setCarregando(true);
    try { setDb(await api.carregarTudo()); } catch { avisar("Falha ao carregar dados", true); setDb({}); }
    setCarregando(false);
  };

  const avisar = (msg, erro = false) => { setToast({ msg, erro }); setTimeout(() => setToast(null), 3000); };

  const entrar = (u) => { localStorage.setItem("metrocasa_user", JSON.stringify(u)); setUsuario(u); };
  const sair = () => { localStorage.removeItem("metrocasa_user"); setUsuario(null); setDb(null); };

  // salvar/atualizar em qualquer tabela
  const salvar = async (table, item, recarrega = true) => {
    const id = await api.salvar(table, item);
    if (recarrega) await carregar();
    return id;
  };
  const excluir = async (table, id) => { await api.excluir(table, id); await carregar(); };

  const registrarHistorico = async (venda_id, acao, detalhe = "") => {
    await api.salvar("historico", { venda_id, usuario: usuario.nome, papel: usuario.perfil, acao, detalhe, criado_em: new Date().toISOString() });
  };

  if (!usuario) return <Login onEntrar={entrar} />;
  if (!db) return <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: CORES.cinza, color: "#5B6B7C", fontFamily: "system-ui" }}>Carregando…</div>;

  const modulosPermitidos = PERFIL_MODULOS[usuario.perfil]; // null = todos
  const podeVer = (m) => !modulosPermitidos || m === "configuracoes" && usuario.perfil === "ADMIN" || (modulosPermitidos && modulosPermitidos.includes(m)) || usuario.perfil === "ADMIN";
  const menuVisivel = MENU.filter(([id]) => usuario.perfil === "ADMIN" || (modulosPermitidos ? modulosPermitidos.includes(id) : true) || (id === "nova" && modulosPermitidos && modulosPermitidos.includes("nova")));

  const vendas = db.vendas || [];

  // notificações
  const notificacoes = [];
  vendas.forEach((v) => {
    const d = diasParado(v.data_estagio);
    const fim = ["E_CONCLUIDO", "X_CANCELADO", "X_DISTRATO", "A_VALIDADO_CEF", "A_VALIDADO_DIRETO"].includes(v.estagio);
    if (!fim && d > 5) notificacoes.push({ tipo: "vermelho", txt: `${v.cliente}: ${d} dias parado em ${estDef(v.estagio).nome}`, v });
    else if (!fim && d > 3) notificacoes.push({ tipo: "amarelo", txt: `${v.cliente}: ${d} dias em ${estDef(v.estagio).nome}`, v });
  });
  (db.pendencias || []).filter((p) => String(p.resolvida).toUpperCase() !== "SIM" && p.resolvida !== true).forEach((p) => {
    const v = vendas.find((x) => x.id === p.venda_id);
    notificacoes.push({ tipo: "amarelo", txt: `Pendência aberta: ${p.descricao}`, v });
  });

  const fonte = "'Segoe UI',system-ui,-apple-system,sans-serif";
  const bgApp = dark ? "#0F1620" : CORES.cinza;
  const txtApp = dark ? "#E8ECF1" : "#1B2733";

  const buscaResultados = busca.trim()
    ? vendas.filter((v) => [v.cliente, v.cpf, v.codigo, v.empreendimento, v.corretor].some((c) => String(c || "").toLowerCase().includes(busca.toLowerCase()))).slice(0, 8)
    : [];

  const props = { db, usuario, dark, salvar, excluir, registrarHistorico, avisar, abrirVenda: setVendaAberta, recarregar: carregar, irPara: setModulo };

  return (
    <div style={{ minHeight: "100vh", background: bgApp, color: txtApp, fontFamily: fonte, display: "flex" }}>
      {/* SIDEBAR */}
      <aside style={{ width: 230, background: dark ? "#141C26" : "#1B2733", color: "#fff", display: "flex", flexDirection: "column", position: "sticky", top: 0, height: "100vh", flexShrink: 0, transform: sidebarAberta ? "none" : undefined }} className="sidebar">
        <div style={{ padding: "18px 18px 14px", borderBottom: "1px solid rgba(255,255,255,.08)" }}>
          <div style={{ fontWeight: 800, fontSize: 19, letterSpacing: 1, color: "#fff" }}>METRO<span style={{ color: CORES.primary }}>CASA</span></div>
          <div style={{ fontSize: 10.5, color: "#8B99A9", marginTop: 2 }}>Gestão de Vendas</div>
        </div>
        <nav style={{ flex: 1, overflowY: "auto", padding: "8px 0" }}>
          {menuVisivel.map(([id, nome, icon]) => (
            <button key={id} onClick={() => { setModulo(id); setSidebarAberta(false); }} style={{ width: "100%", textAlign: "left", display: "flex", alignItems: "center", gap: 10, padding: "10px 18px", background: modulo === id ? CORES.primary : "transparent", color: "#fff", border: "none", cursor: "pointer", fontSize: 13.5, fontWeight: modulo === id ? 700 : 500, fontFamily: fonte }}>
              <span style={{ width: 18, textAlign: "center", opacity: 0.9 }}>{icon}</span>{nome}
            </button>
          ))}
        </nav>
        <div style={{ padding: 14, borderTop: "1px solid rgba(255,255,255,.08)", fontSize: 12 }}>
          <div style={{ fontWeight: 700 }}>{usuario.nome}</div>
          <div style={{ color: "#8B99A9", fontSize: 11 }}>{PERFIL_NOME[usuario.perfil]}{api.modo === "demo" ? " · demo" : ""}</div>
          <button onClick={sair} style={{ marginTop: 8, background: "transparent", color: "#9FB0C2", border: "1px solid #34465A", borderRadius: 6, padding: "5px 10px", fontSize: 12, cursor: "pointer", width: "100%", fontFamily: fonte }}>Sair</button>
        </div>
      </aside>

      {/* CONTEÚDO */}
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        {/* topbar */}
        <header style={{ background: dark ? "#141C26" : "#fff", borderBottom: `1px solid ${dark ? "#222B36" : "#E2E7EE"}`, padding: "10px 16px", display: "flex", alignItems: "center", gap: 12, position: "sticky", top: 0, zIndex: 20 }}>
          <button onClick={() => setSidebarAberta(!sidebarAberta)} className="btn-menu" style={{ display: "none", background: "transparent", border: "none", fontSize: 20, cursor: "pointer", color: txtApp }}>☰</button>
          <div style={{ position: "relative", flex: 1, maxWidth: 420 }}>
            <input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar venda, cliente, CPF, corretor…" style={{ width: "100%", padding: "8px 12px", borderRadius: 8, border: `1px solid ${dark ? "#2A3340" : "#D5DBE3"}`, background: dark ? "#1A222C" : "#fff", color: txtApp, fontSize: 13, outline: "none" }} />
            {buscaResultados.length > 0 && (
              <div style={{ position: "absolute", top: 40, left: 0, right: 0, background: dark ? "#1A222C" : "#fff", border: `1px solid ${dark ? "#2A3340" : "#E2E7EE"}`, borderRadius: 8, boxShadow: "0 8px 24px rgba(0,0,0,.15)", zIndex: 30, overflow: "hidden" }}>
                {buscaResultados.map((v) => (
                  <div key={v.id} onClick={() => { setVendaAberta(v); setBusca(""); }} style={{ padding: "9px 12px", cursor: "pointer", borderBottom: `1px solid ${dark ? "#222B36" : "#F0F2F6"}`, fontSize: 13 }}>
                    <b>{v.cliente}</b> <span style={{ color: "#8B99A9", fontSize: 11.5 }}>· {v.empreendimento || "—"} · {estDef(v.estagio).nome}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
            <NotifSino notificacoes={notificacoes} dark={dark} abrir={(v) => v && setVendaAberta(v)} />
            <button onClick={() => setDark(!dark)} title="Tema" style={{ background: "transparent", border: `1px solid ${dark ? "#2A3340" : "#D5DBE3"}`, borderRadius: 8, padding: "7px 10px", cursor: "pointer", fontSize: 14, color: txtApp }}>{dark ? "☀" : "☾"}</button>
          </div>
        </header>

        <main style={{ flex: 1, minWidth: 0 }}>
          {carregando && <div style={{ padding: 8, textAlign: "center", fontSize: 12, color: "#8B99A9" }}>sincronizando…</div>}
          {modulo === "dashboard" && <Dashboard {...props} />}
          {modulo === "nova" && <NovaVenda {...props} />}
          {modulo === "esteira" && <Esteira {...props} filtroEtapa={null} titulo="Esteira Comercial" />}
          {modulo === "secretaria" && <Esteira {...props} filtroEtapa="SECRETARIA" titulo="Secretaria de Vendas" />}
          {modulo === "credito" && <Esteira {...props} filtroEtapa="CREDITO" titulo="Crédito" />}
          {modulo === "assinaturas" && <Esteira {...props} filtroEtapa="ASSINATURA" titulo="Assinaturas" />}
          {modulo === "validadas" && <ListaSimples {...props} tipo="validadas" />}
          {modulo === "pendencias" && <ListaSimples {...props} tipo="pendencias" />}
          {modulo === "distratos" && <Distratos {...props} />}
          {modulo === "clientes" && <ListaSimples {...props} tipo="clientes" />}
          {modulo === "corretores" && <Cadastros {...props} tabela="corretores" />}
          {modulo === "empreendimentos" && <Cadastros {...props} tabela="empreendimentos" />}
          {modulo === "documentos" && <ListaSimples {...props} tipo="documentos" />}
          {modulo === "relatorios" && <Relatorios {...props} />}
          {modulo === "configuracoes" && <Cadastros {...props} tabela="__config" />}
        </main>
      </div>

      {vendaAberta && (
        <DetalheVenda venda={(db.vendas || []).find((v) => v.id === vendaAberta.id) || vendaAberta} {...props} fechar={() => setVendaAberta(null)} />
      )}

      {toast && <div style={{ position: "fixed", bottom: 20, left: "50%", transform: "translateX(-50%)", background: toast.erro ? "#B03A3A" : "#1B2733", color: "#fff", padding: "10px 18px", borderRadius: 8, fontSize: 13, fontWeight: 600, zIndex: 99, boxShadow: "0 4px 14px rgba(0,0,0,.25)" }}>{toast.msg}</div>}

      <style>{`
        @media (max-width: 760px) {
          .sidebar { position: fixed !important; z-index: 60; left: 0; top: 0; transition: transform .2s; }
          .sidebar { transform: translateX(${sidebarAberta ? "0" : "-240px"}) !important; }
          .btn-menu { display: block !important; }
        }
      `}</style>
    </div>
  );
}

function NotifSino({ notificacoes, dark, abrir }) {
  const [aberto, setAberto] = useState(false);
  return (
    <div style={{ position: "relative" }}>
      <button onClick={() => setAberto(!aberto)} style={{ background: "transparent", border: `1px solid ${dark ? "#2A3340" : "#D5DBE3"}`, borderRadius: 8, padding: "7px 10px", cursor: "pointer", fontSize: 14, position: "relative", color: dark ? "#E8ECF1" : "#1B2733" }}>
        🔔
        {notificacoes.length > 0 && <span style={{ position: "absolute", top: -6, right: -6, background: CORES.primary, color: "#fff", fontSize: 10, fontWeight: 700, borderRadius: 10, padding: "1px 5px" }}>{notificacoes.length}</span>}
      </button>
      {aberto && (
        <div style={{ position: "absolute", top: 42, right: 0, width: 320, maxHeight: 380, overflowY: "auto", background: dark ? "#1A222C" : "#fff", border: `1px solid ${dark ? "#2A3340" : "#E2E7EE"}`, borderRadius: 10, boxShadow: "0 8px 24px rgba(0,0,0,.18)", zIndex: 40 }}>
          <div style={{ padding: "10px 14px", fontWeight: 700, fontSize: 13, borderBottom: `1px solid ${dark ? "#222B36" : "#F0F2F6"}` }}>Notificações ({notificacoes.length})</div>
          {notificacoes.length === 0 && <div style={{ padding: 14, fontSize: 12.5, color: "#8B99A9" }}>Tudo em dia.</div>}
          {notificacoes.slice(0, 30).map((n, i) => (
            <div key={i} onClick={() => { abrir(n.v); setAberto(false); }} style={{ padding: "9px 14px", borderBottom: `1px solid ${dark ? "#222B36" : "#F0F2F6"}`, fontSize: 12.5, cursor: n.v ? "pointer" : "default", display: "flex", gap: 8, alignItems: "flex-start" }}>
              <span style={{ width: 8, height: 8, borderRadius: "50%", background: n.tipo === "vermelho" ? "#B03A3A" : "#C77E1B", marginTop: 4, flexShrink: 0 }} />
              <span>{n.txt}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
