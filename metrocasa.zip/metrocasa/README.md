# Metrocasa — Gestão de Vendas e Contratos

Sistema web (CRM + ERP + Workflow) para a jornada completa da venda imobiliária da Metrocasa: da proposta à entrega ou distrato. Integrado ao Google Sheets, com login por perfil, kanban, checklists, distratos, análise por IA e dashboard.

![build](https://img.shields.io/badge/build-passing-2E8B57) ![stack](https://img.shields.io/badge/React%2018%20%2B%20Vite-D71920)

## Módulos

Dashboard · Nova Venda · Esteira Comercial · Secretaria de Vendas · Crédito · Assinaturas · Validadas · Pendências · Distratos · Clientes · Corretores · Empreendimentos · Documentos · Relatórios · Configurações.

- **Fluxo completo** em 5 etapas (Comercial → Secretaria → Crédito → Assinaturas → Entrega) com todos os 30+ estágios do processo, em **kanban drag-and-drop**.
- **Detalhe da venda** com abas: Dados Gerais, checklist de SV, checklist de Crédito, Pendências, Documentos, IA e Histórico (timeline).
- **Distratos**: módulo próprio com os 9 status, dashboard (quantidade, valor devolvido, motivos, por empreendimento).
- **IA**: análise automática de risco (baixo/médio/alto) verificando divergência de valores, renda incompatível, SICAQ vencido, campos vazios e documentação pendente.
- **Dashboard** com cards, SLA por etapa, ranking de analistas e corretores, indicadores por empreendimento.
- **Notificações**: alertas de itens parados (>3 dias amarelo, >5 vermelho), pendências e assinaturas.
- **Perfis de acesso** (Admin, Gerente, Diretor, SV, Crédito, Assistente, Jurídico, Financeiro, Comercial) — cada um vê só seus módulos.
- **Busca global**, **dark mode**, **responsivo mobile**, cores Metrocasa (#D71920).

## Rodar localmente

```bash
npm install
npm run dev
```
Abre em http://localhost:5173. Sem configurar nada, roda em **modo demonstração** (dados salvos no navegador, qualquer e-mail entra como Admin).

## Publicar na Vercel

1. Suba este repositório no GitHub (veja `SUBIR-NO-GITHUB.md`).
2. Em vercel.com → **Add New → Project** → selecione o repositório → **Deploy**.
3. Configure as variáveis (abaixo) e clique em **Redeploy**.

## Integração Google Sheets (dados reais + login)

O backend é um Google Apps Script que transforma uma planilha em API. Passo a passo em [`api/INSTALAR-BACKEND.md`](./api/INSTALAR-BACKEND.md). Resumo:

1. Crie uma planilha → Extensões → Apps Script → cole `api/apps-script-backend.gs`.
2. Rode a função `instalar` (cria as abas e o usuário admin).
3. Implante como App da Web e copie a URL `/exec`.
4. Na Vercel, defina as variáveis:

| Variável | Para quê |
|---|---|
| `VITE_API_URL` | URL `/exec` do Apps Script |
| `VITE_API_TOKEN` | o token definido no script |
| `ANTHROPIC_API_KEY` | botão de análise por IA (fica no servidor, protegida) |

Sem `VITE_API_URL`/`VITE_API_TOKEN`, o sistema roda em modo demo. Com elas, grava e lê do Sheets (bidirecional) e o login passa a ser real.

## Limitações honestas

- **Upload de documentos**: o sistema guarda **links** (Google Drive) por tipo de documento. Upload do arquivo físico exigiria armazenamento (ex.: Drive API / S3) — pode ser adicionado depois.
- **LGPD**: a base tem CPF e renda. O CPF aparece mascarado nas listas. Para produção, restrinja o token e considere um backend dedicado.

## Estrutura

```
metrocasa/
├── api/
│   ├── apps-script-backend.gs   # backend Google Sheets (cole no Apps Script)
│   ├── analisar.js              # função serverless da IA (Vercel)
│   └── INSTALAR-BACKEND.md
└── src/
    ├── App.jsx                  # sidebar, busca, dark mode, notificações, rotas
    ├── lib/{defs,api}.js        # definições e camada de dados
    ├── components/ui.jsx        # cards, gráficos, drawer
    └── modules/                 # Dashboard, Esteira, DetalheVenda, Distratos, etc.
```

## Licença

MIT.
