// Função serverless (Vercel) — análise de risco por IA. Chave protegida no servidor.
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ erro: "use POST" });
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(200).json({ erro: "IA não configurada" });
  try {
    const { payload } = req.body;
    const prompt =
      `Você é analista sênior de validação de contratos imobiliários MCMV da Metrocasa (Secretaria de Vendas + Crédito). ` +
      `Analise a venda e responda APENAS JSON {"risco":"baixo"|"medio"|"alto","pendencias_provaveis":["..."],"resumo":"..."}. ` +
      `Verifique: diferença entre valor de venda e avaliação, renda incompatível com a faixa (HIS-1 até 4.863, HIS-2 até 9.726), ` +
      `SICAQ vencido/incompleto, campos críticos vazios (CPF, telefone, valores, unidade), documentação pendente, ` +
      `itens de checklist em VERIFICAR. Resumo em até 3 frases, português.\n\nDADOS:\n${JSON.stringify(payload)}`;
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: 1000, messages: [{ role: "user", content: prompt }] }),
    });
    return res.status(200).json(await r.json());
  } catch (e) {
    return res.status(200).json({ erro: "falha na análise" });
  }
}
