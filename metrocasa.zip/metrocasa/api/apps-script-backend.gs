/**
 * ============================================================
 * METROCASA — BACKEND (Google Apps Script)
 * API REST bidirecional com Google Sheets + login.
 * ============================================================
 * INSTALAÇÃO:
 * 1. Crie uma planilha no Google Sheets.
 * 2. Extensões → Apps Script → cole este arquivo.
 * 3. Rode a função `instalar` uma vez (cria as abas e o admin).
 * 4. Implantar → Nova implantação → App da Web:
 *    - Executar como: Você
 *    - Quem pode acessar: Qualquer pessoa com o link
 * 5. Copie a URL /exec e use no front (VITE_API_URL).
 * 6. Troque o TOKEN abaixo.
 */

const TOKEN = 'TROQUE-ESTE-TOKEN';

// Cada tabela é uma aba. A 1ª linha são os cabeçalhos (campos).
const TABELAS = {
  vendas: ['id','codigo','processo','link','cliente','cpf','telefone','email','empreendimento','unidade','tipologia','renda','vlr_venda','vlr_avaliacao','banco','repasse','categoria','sicaq','data_contrato','corretor','gerente','diretor','analista_sv','analista_credito','assistente','estagio','data_estagio','obs','checklist_sv','checklist_credito','documentos','criado_em','atualizado_em'],
  distratos: ['id','venda_id','cliente','empreendimento','motivo','data_solicitacao','valor_pago','valor_devolvido','percentual_retencao','responsavel','status','obs','documentos','criado_em','atualizado_em'],
  pendencias: ['id','venda_id','tipo','descricao','responsavel','status','comentario','resolvida','criado_em','resolvida_em'],
  historico: ['id','venda_id','usuario','papel','acao','detalhe','criado_em'],
  corretores: ['id','nome','telefone','email','gerente','ativo'],
  gerentes: ['id','nome','email','diretor','ativo'],
  diretores: ['id','nome','email','ativo'],
  analistas: ['id','nome','email','area','ativo'], // area: SV | CREDITO | ASSISTENTE
  empreendimentos: ['id','nome','cidade','tipologia','total_unidades','ativo'],
  bancos: ['id','nome','ativo'],
  motivos_distrato: ['id','nome','ativo'],
  tipos_pendencia: ['id','nome','ativo'],
  usuarios: ['id','nome','email','senha','perfil','ativo'], // perfil: ADMIN|GERENTE|DIRETOR|SV|CREDITO|ASSISTENTE|JURIDICO|FINANCEIRO|COMERCIAL
};

function instalar() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(TABELAS).forEach((nome) => {
    let sh = ss.getSheetByName(nome);
    if (!sh) sh = ss.insertSheet(nome);
    if (sh.getLastRow() === 0) {
      sh.getRange(1, 1, 1, TABELAS[nome].length).setValues([TABELAS[nome]]).setFontWeight('bold');
      sh.setFrozenRows(1);
    }
  });
  // cria admin padrão se não existir
  const u = ss.getSheetByName('usuarios');
  if (u.getLastRow() < 2) {
    u.appendRow(['u1', 'Administrador', 'admin@metrocasa.com', 'metrocasa', 'ADMIN', 'SIM']);
  }
  return 'Instalado. Login: admin@metrocasa.com / senha: metrocasa';
}

function getSheet_(nome) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(nome);
  if (!sh) { sh = ss.insertSheet(nome); sh.getRange(1, 1, 1, TABELAS[nome].length).setValues([TABELAS[nome]]); }
  return sh;
}
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

function lerTabela_(nome) {
  const sh = getSheet_(nome);
  const last = sh.getLastRow();
  if (last < 2) return [];
  const cols = TABELAS[nome];
  const dados = sh.getRange(2, 1, last - 1, cols.length).getValues();
  return dados.map((row) => {
    const o = {};
    cols.forEach((c, i) => { o[c] = row[i] instanceof Date ? row[i].toISOString() : row[i]; });
    return o;
  }).filter((o) => o.id !== '' && o.id != null);
}

function acharLinha_(sh, id) {
  const ids = sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 1), 1).getValues().flat();
  const idx = ids.findIndex((v) => String(v) === String(id));
  return idx === -1 ? -1 : idx + 2;
}

function upsert_(nome, item) {
  const sh = getSheet_(nome);
  const cols = TABELAS[nome];
  const now = new Date().toISOString();
  if (!item.id) item.id = nome.charAt(0) + Date.now().toString(36);
  if (cols.includes('criado_em') && !item.criado_em) item.criado_em = now;
  if (cols.includes('atualizado_em')) item.atualizado_em = now;
  const linha = acharLinha_(sh, item.id);
  const valores = cols.map((c) => {
    const v = item[c];
    if (v == null) return '';
    return typeof v === 'object' ? JSON.stringify(v) : v;
  });
  if (linha === -1) sh.appendRow(valores);
  else sh.getRange(linha, 1, 1, cols.length).setValues([valores]);
  return item.id;
}

function excluir_(nome, id) {
  const sh = getSheet_(nome);
  const linha = acharLinha_(sh, id);
  if (linha !== -1) sh.deleteRow(linha);
}

// -------- GET: ?token=..&action=all  | &action=table&name=vendas --------
function doGet(e) {
  const p = e.parameter || {};
  if (p.token !== TOKEN) return json_({ ok: false, error: 'token inválido' });
  if (p.action === 'table' && p.name) return json_({ ok: true, items: lerTabela_(p.name) });
  // all: devolve tudo de uma vez (front carrega o estado inteiro)
  const out = {};
  Object.keys(TABELAS).forEach((nome) => { if (nome !== 'usuarios') out[nome] = lerTabela_(nome); });
  return json_({ ok: true, data: out });
}

// -------- POST: { token, action, ... } --------
function doPost(e) {
  let body;
  try { body = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'JSON inválido' }); }
  if (body.token !== TOKEN) return json_({ ok: false, error: 'token inválido' });

  // login: { action:'login', email, senha }
  if (body.action === 'login') {
    const us = lerTabela_('usuarios');
    const u = us.find((x) => String(x.email).toLowerCase() === String(body.email).toLowerCase() && String(x.senha) === String(body.senha) && String(x.ativo).toUpperCase() !== 'NAO');
    if (!u) return json_({ ok: false, error: 'credenciais inválidas' });
    return json_({ ok: true, usuario: { id: u.id, nome: u.nome, email: u.email, perfil: u.perfil } });
  }

  // upsert: { action:'save', table, item }
  if (body.action === 'save') {
    const id = upsert_(body.table, body.item);
    return json_({ ok: true, id });
  }
  // salvar vários: { action:'saveMany', table, items:[] }
  if (body.action === 'saveMany') {
    const ids = (body.items || []).map((it) => upsert_(body.table, it));
    return json_({ ok: true, ids });
  }
  // excluir: { action:'delete', table, id }
  if (body.action === 'delete') {
    excluir_(body.table, body.id);
    return json_({ ok: true });
  }
  // gestão de usuários (só o front de admin chama)
  if (body.action === 'usuarios') return json_({ ok: true, items: lerTabela_('usuarios') });
  if (body.action === 'saveUsuario') { const id = upsert_('usuarios', body.item); return json_({ ok: true, id }); }

  return json_({ ok: false, error: 'action desconhecida' });
}
