# Instalar o backend (Google Sheets)

Isto liga o sistema ao Google Sheets: dados reais, sincronização nos dois sentidos e login por usuário. Leva ~15 min.

## Passos

1. Crie uma planilha nova no Google Sheets (vai ser o banco de dados).
2. **Extensões → Apps Script**.
3. Apague o conteúdo do `Code.gs` e cole o arquivo `apps-script-backend.gs`.
4. Na linha `const TOKEN = 'TROQUE-ESTE-TOKEN';`, troque por uma senha forte sua.
5. No topo, selecione a função **`instalar`** e clique em **Executar**. Autorize as permissões. Isso cria todas as abas (vendas, distratos, pendências, histórico, corretores, etc.) e um usuário admin:
   - **e-mail:** admin@metrocasa.com
   - **senha:** metrocasa
   (troque depois na aba `usuarios`.)
6. **Implantar → Nova implantação → App da Web**:
   - Executar como: **Você**
   - Quem pode acessar: **Qualquer pessoa com o link**
7. Copie a URL gerada (termina em `/exec`).
8. Teste no navegador:
   `SUA_URL/exec?token=SUA_SENHA&action=all`
   Deve retornar `{"ok":true,"data":{...}}`.

## Conectar no app

Na Vercel (ou no `.env` local), defina:

```
VITE_API_URL=  (a URL /exec)
VITE_API_TOKEN=  (a senha que você definiu)
```

Refaça o deploy. Pronto: login real e tudo gravando na planilha.

## Importante

- A URL `/exec` + token funcionam como senha do banco. Não divulgue.
- Ao editar o script depois, use **Gerenciar implantações → editar → Nova versão** para manter a mesma URL.
- Cada aba da planilha é uma tabela; a primeira linha são os campos. Você pode consultar os dados direto na planilha a qualquer momento.

## Usuários e perfis

Na aba `usuarios`, cada linha é um acesso. A coluna `perfil` aceita: ADMIN, GERENTE, DIRETOR, SV, CREDITO, ASSISTENTE, JURIDICO, FINANCEIRO, COMERCIAL. Cada perfil enxerga apenas seus módulos (configurável em `src/lib/defs.js` → `PERFIL_MODULOS`). Você também cria usuários pela tela **Configurações** dentro do sistema (como admin).
